import json,os,sys
from pathlib import Path
sys.path.insert(0, '/Users/devilhill/Codes/cubeql/tools')
import serve_encoder as worker
original=worker._diagnostic
def diagnostic(event, **fields):
    with Path('/Users/devilhill/Documents/ChatGPT/cubeql/mcp-reload-stack/process-attempt1/encoder-events.jsonl').open('a') as stream:
        stream.write(json.dumps({'event':event,'pid':os.getpid(),'parent_pid':os.getppid(),'peak_rss_bytes':worker._peak_rss_bytes(),**fields})+'\n')
    original(event,**fields)
worker._diagnostic=diagnostic
raise SystemExit(worker.main())
