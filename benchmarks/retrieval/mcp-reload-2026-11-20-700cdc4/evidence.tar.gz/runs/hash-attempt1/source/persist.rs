/// Persist application settings.
pub fn persist_settings() { write_settings(); }
