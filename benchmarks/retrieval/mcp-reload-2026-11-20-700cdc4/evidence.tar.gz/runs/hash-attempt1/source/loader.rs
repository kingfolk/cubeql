/// Load current application settings.
pub fn load_current_settings() { current_settings(); }
