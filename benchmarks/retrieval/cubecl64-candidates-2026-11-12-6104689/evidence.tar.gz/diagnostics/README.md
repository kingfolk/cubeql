# Native symbol-label diagnostics

Dataset: `cubecl-combined-development-v2` (64 queries; native `(path, symbol)` labels).

| Precision | Strategy | Queries | Recall@5 | Recall@10 | MRR |
|---|---:|---:|---:|---:|---:|
| fp32 | semantic | 64 | 0.473958 | 0.559896 | 0.385504 |
| fp32 | literal | 64 | 0.250000 | 0.250000 | 0.250000 |
| fp32 | experimental_rrf | 64 | 0.520833 | 0.591146 | 0.470404 |
| fp32 | lexical | 64 | 0.419271 | 0.549479 | 0.383519 |
| fp32 | symbol | 64 | 0.250000 | 0.250000 | 0.250465 |
| fp32 | hybrid | 64 | 0.627604 | 0.729167 | 0.545637 |

Paired outcomes compare semantic with lexical, symbol, or hybrid using per-query Recall@10. Full per-query deltas and first relevant ranks are in `diagnostics.json`.

## Complete final window (100 maximum)

| Precision | Strategy | Window recall | All required | Recomputed MRR |
| --- | --- | ---: | ---: | ---: |
| fp32 | semantic | 0.763021 | 0.718750 | 0.385504 |
| fp32 | literal | 0.250000 | 0.250000 | 0.250000 |
| fp32 | experimental_rrf | 0.763021 | 0.718750 | 0.470404 |
| fp32 | lexical | 0.884115 | 0.828125 | 0.383519 |
| fp32 | symbol | 0.273438 | 0.265625 | 0.250465 |
| fp32 | hybrid | 0.878906 | 0.843750 | 0.545637 |

Full exported ranks independently validate MRR beyond ten. The window is the final retained ranking; missing anchors do not establish failure of an internal candidate generator.

This is a saved original symbol-label development observation. Warm repeats are not independent quality samples. It establishes no causal diagnosis, equal-work speedup, or agent outcome. No source-span conversion is performed. Native latency is omitted.
