"""Assemble reviewable evidence from the completed evaluate-only run; no inference."""
from pathlib import Path
import hashlib, io, json, subprocess, tarfile
REPO=Path('/Users/devilhill/Codes/cubeql')
WORK=Path('/Users/devilhill/Documents/ChatGPT/cubeql')
STAGE=WORK/'rq2-candidate-stack'
RUN=STAGE/'original64-candidates-attempt1'
DIAG=STAGE/'original64-diagnostics'
OLD=WORK/'rq2-live-stack/full64-2026-11-12-attempt1'
DEST=REPO/'benchmarks/retrieval/cubecl64-candidates-2026-11-12-6104689'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(d):return (json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
def main():
    execution=json.loads((RUN/'execution.json').read_bytes())
    assert execution['status']=='ok'
    inp=json.loads((RUN/'inputs.json').read_bytes())
    comparison=json.loads((RUN/'comparison.json').read_bytes())
    full=json.loads((DIAG/'diagnostics.json').read_bytes())
    raw=json.loads((RUN/'evaluate.stdout').read_bytes())
    recipe=json.loads((OLD/'recipe.json').read_bytes())
    members={}
    for prefix,folder in [('run',RUN),('diagnostics',DIAG)]:
        for p in sorted(folder.iterdir()):
            if p.is_file():members[prefix+'/'+p.name]=p.read_bytes()
    for name in ['recipe.json','profile-000-evaluate.stdout','manifest.json']:
        members['original/'+name]=(OLD/name).read_bytes()
    members['inputs/queries.json']=(WORK/'rq2-live-stack/prepared64/recipe/queries.json').read_bytes()
    members['inputs/source-preparation.json']=(WORK/'rq2-live-stack/prepared64/source-preparation.json').read_bytes()
    for name in ['repository_native_diagnostics.py','repository_baseline.py','repository_collect.py','repository_eval.py','serve_encoder.py']:
        members['producer/tools/'+name]=(REPO/'tools'/name).read_bytes()
    for name in ['evaluation.rs','hybrid_evaluation.rs','main.rs']:
        members['producer/crates/cubeql-code/src/'+name]=(REPO/'crates/cubeql-code/src'/name).read_bytes()
    members['producer/replay.py']=(STAGE/'replay.py').read_bytes()
    members['producer/package.py']=Path(__file__).read_bytes()
    profile=json.loads(Path(recipe['config']['profiles'][0]['encoder_config']).read_bytes())
    members['inputs/encoder-config.json']=Path(recipe['config']['profiles'][0]['encoder_config']).read_bytes()
    members['runtime/requirements-observed-after-run.txt']=subprocess.check_output([profile['command'],'-m','pip','freeze','--all'])
    summary={name:{key:value for key,value in detail.items() if key!='queries'}
             for name,detail in full['variants'][0]['candidate_window'].items()}
    hybrid=full['variants'][0]['candidate_window']['hybrid']
    top={'format_version':1,'native_report_version':3,'candidate_k':full['options']['candidate_k'],
         'source':full['source'],'strategies':summary,
         'hybrid_incomplete_top10':[q for q in hybrid['queries'] if q['failure_class']!='all_locations_in_top10'],
         'limits':full['interpretation_limits']}
    metadata={'format_version':1,'recorded_engine_revision':'6104689',
         'binary_build_revision_independently_attested':False,
         'binary_sha256':inp['observed_inputs_before']['binary_sha256'],
         'original_binary_sha256':inp['old_binary_sha256'],
         'original_recipe_fingerprint':inp['original_recipe_fingerprint'],
         'preserved_snapshot_sha256':inp['original_snapshot_sha256'],
         'queries_sha256':recipe['inputs']['queries_sha256'],
         'corpus_revision':'5037c0639ce3b1205392bdbe43dcf25e2ea09e29',
         'snapshot':raw['evaluation']['variants'][0]['snapshot'],
         'native_options':raw['evaluation']['options'],
         'evaluation_wall_ms':execution['elapsed_ms'],'document_encoding_reused':True,
         'query_encoding':'live local fixed CodeRank256 CPU; no query-vector replay claim',
         'paid_api_or_agent_calls':0,'snapshot_and_models_excluded':True,
         'producer_sha256':{name:sha(content) for name,content in members.items() if name.startswith('producer/')},
         'runtime_lock_boundary':'Observed after execution, not a hermetic environment attestation.'}
    DEST.mkdir(exist_ok=False)
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
        for name,content in sorted(members.items()):
            info=tarfile.TarInfo(name);info.size=len(content);info.mode=0o644;info.mtime=0
            archive.addfile(info,io.BytesIO(content))
    (DEST/'evidence.tar.gz').write_bytes(buffer.getvalue())
    (DEST/'evidence-members.json').write_bytes(enc({name:sha(value) for name,value in sorted(members.items())}))
    (DEST/'window-summary.json').write_bytes(enc(top))
    (DEST/'experiment.json').write_bytes(enc(metadata))
    (DEST/'comparison.json').write_bytes(enc(comparison))
    print(json.dumps({'destination':str(DEST),'archive_members':len(members),'archive_bytes':len(buffer.getvalue()),'uncompressed_bytes':sum(map(len,members.values()))}))
if __name__=='__main__':main()
