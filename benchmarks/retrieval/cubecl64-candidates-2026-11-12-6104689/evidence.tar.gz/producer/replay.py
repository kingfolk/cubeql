"""Run one fixed evaluate-only condition on the preserved original64 Arrow snapshot."""
from pathlib import Path
import hashlib
import json
import sys
sys.path.insert(0, '/Users/devilhill/Codes/cubeql/tools')
import repository_baseline as baseline
import repository_collect as runner
import repository_eval as ev

REPO=Path('/Users/devilhill/Codes/cubeql')
WORK=Path('/Users/devilhill/Documents/ChatGPT/cubeql')
OLD=WORK/'rq2-live-stack/full64-2026-11-12-attempt1'
RECIPE=WORK/'rq2-live-stack/prepared64/recipe'
OUT=WORK/'rq2-candidate-stack/original64-candidates-attempt1'

def main():
    recipe=ev._load(RECIPE/'recipe.json')
    assert recipe['fingerprint']==ev._digest({k:v for k,v in recipe.items() if k!='fingerprint'})
    config=baseline._normalize(dict(recipe['config'],queries=str(RECIPE/'queries.json')),RECIPE)
    expected=recipe['inputs']
    before=baseline._inputs(config,RECIPE/'queries.json')
    # New exporter binary is the only intended change from the old measurement inputs.
    assert {k:v for k,v in before.items() if k!='binary_sha256'}=={k:v for k,v in expected.items() if k!='binary_sha256'}
    manifest=ev._load(OLD/'manifest.json')
    for name,digest in manifest.items():
        assert runner.sha256_file(OLD/name)==digest, name
    snapshot=OLD/'profile-000.arrow'
    command=[config['binary'],'evaluate',str(snapshot),str(RECIPE/'queries.json'),
             '--encoder-config',config['profiles'][0]['encoder_config'],
             '--candidate-k',str(config['candidate_k']),'--repeats',str(config['repeats']),
             '--export-candidates','--format','json']
    OUT.mkdir(exist_ok=False)
    ev._write_new(OUT/'inputs.json',{'original_recipe_fingerprint':recipe['fingerprint'],
         'original_snapshot_sha256':manifest['profile-000.arrow'], 'old_binary_sha256':expected['binary_sha256'],
         'observed_inputs_before':before,'options':{k:config[k] for k in ('candidate_k','repeats','compare_fp16','timeout_seconds')},
         'document_encoding_reused':True,'capture_limit_bytes':67108864,'query_encoding':'live local CodeRank256 CPU; no query-vector replay claim'})
    execution=runner.execute(command,OUT,'evaluate',timeout_s=config['timeout_seconds'],max_output_bytes=67108864)
    ev._write_new(OUT/'execution.json',execution)
    after=baseline._inputs(config,RECIPE/'queries.json')
    assert before==after,'inputs changed during execution'
    assert runner.sha256_file(snapshot)==manifest['profile-000.arrow'],'saved snapshot changed'
    ev._write_new(OUT/'inputs-after.json',after)
    if execution['status']!='ok':
        raise RuntimeError('evaluation failed; raw failure preserved')
    old=ev._load(OLD/'profile-000-evaluate.stdout')['evaluation']
    new=ev._load(OUT/'evaluate.stdout')['evaluation']
    assert new['format_version']==3
    assert new['dataset']==old['dataset'] and new['options']==old['options']
    deltas=[]
    for bv,av in zip(old['variants'],new['variants'],strict=True):
        assert bv['snapshot']==av['snapshot'],'snapshot metadata changed'
        for b,a in zip(bv['queries'],av['queries'],strict=True):
            assert b['id']==a['id']
            for name in ('semantic','literal','experimental_rrf','lexical','symbol','hybrid'):
                if b[name]['metrics']!=a[name]['metrics'] or b[name]['top_hits']!=a[name]['top_hits']:
                    deltas.append({'query_id':b['id'],'strategy':name,'old_metrics':b[name]['metrics'],
                                   'new_metrics':a[name]['metrics'],'display_hits_identical':b[name]['top_hits']==a[name]['top_hits']})
    ev._write_new(OUT/'comparison.json',{'query_count':len(new['dataset']['queries']),
         'strategy_count':6,'changed_metric_or_display_cases':deltas,
         'all_original_metrics_and_display_hits_identical':not deltas,
         'limits':'New executable, same preserved document vectors and local live query encoder; not an engine speedup comparison.'})
    ev._write_new(OUT/'manifest.json',{p.name:runner.sha256_file(p) for p in sorted(OUT.iterdir()) if p.is_file()})
    print(json.dumps({'status':'ok','output':str(OUT),'changed_cases':len(deltas),'elapsed_ms':execution['elapsed_ms']}))

if __name__=='__main__':main()
