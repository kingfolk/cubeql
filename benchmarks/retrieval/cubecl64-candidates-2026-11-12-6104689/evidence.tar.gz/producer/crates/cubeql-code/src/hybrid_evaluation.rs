//! Current retrieval evaluation layered over an unchanged M6 baseline. Capturing the baseline's
//! query embeddings avoids re-encoding queries and preserves exact precision-comparison inputs.
use std::{
    collections::{BTreeMap, BTreeSet},
    time::Instant,
};

use cubecl::Device;
use cubeql_embeddings::{
    EmbeddedQuery, EmbeddingConfig, EmbeddingError, EmbeddingInput, EmbeddingProvider,
};
use serde::Serialize;

use crate::{
    CodeError, CodeIndex, CodeSearchIndex,
    evaluation::{
        self, EvaluationOptions, Latency, QualitySummary, QueryCategory, QueryResult, QuerySet,
        RankedCandidate, RankingMetrics, ranking_metrics,
    },
    invalid,
    reporting::{SnapshotInfo, elapsed_ms},
    retrieval::{
        RetrievalHit, RetrievalOptions, RetrievedCodeHit, SearchStrategy, SnapshotTextIndex,
        materialize_hits,
    },
};

#[derive(Serialize)]
pub struct RetrievalStrategyResult {
    pub metrics: RankingMetrics,
    pub retrieval: Latency,
    pub materialization_ms: f64,
    pub top_hits: Vec<RetrievedCodeHit>,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub candidate_ranking: Option<Vec<RankedCandidate>>,
}

#[derive(Serialize)]
pub struct HybridQueryResult {
    #[serde(flatten)]
    pub baseline: QueryResult,
    /// Current adapters' filter preparation, separate from the original baseline's timer.
    pub hybrid_filter_ms: f64,
    pub lexical: RetrievalStrategyResult,
    pub symbol: RetrievalStrategyResult,
    pub hybrid: RetrievalStrategyResult,
}

#[derive(Serialize)]
pub struct HybridVariantReport {
    pub snapshot: SnapshotInfo,
    pub baseline_conversion_ms: f64,
    pub baseline_upload_ms: f64,
    pub conversion_ms: f64,
    pub upload_ms: f64,
    pub text_index_ms: f64,
    pub queries: Vec<HybridQueryResult>,
    pub overall: BTreeMap<String, QualitySummary>,
    pub by_category: BTreeMap<QueryCategory, BTreeMap<String, QualitySummary>>,
}

#[derive(Serialize)]
pub struct HybridEvaluationReport {
    pub format_version: u32,
    pub dataset: QuerySet,
    pub backend: String,
    pub options: EvaluationOptions,
    pub rrf_rank_constant: usize,
    pub embedding_total_ms: f64,
    pub embedding_execution: String,
    pub variants: Vec<HybridVariantReport>,
}

struct CaptureQueries<'a> {
    provider: &'a mut dyn EmbeddingProvider,
    vectors: Vec<Vec<f32>>,
}
impl EmbeddingProvider for CaptureQueries<'_> {
    fn config(&self) -> &EmbeddingConfig {
        self.provider.config()
    }
    fn requires_identified_inputs(&self) -> bool {
        self.provider.requires_identified_inputs()
    }
    fn execution_kind(&self) -> &'static str {
        self.provider.execution_kind()
    }
    fn validate_query_inputs(&self, inputs: &[EmbeddingInput]) -> Result<(), EmbeddingError> {
        self.provider.validate_query_inputs(inputs)
    }
    fn embed_query_with_id(&mut self, input: &EmbeddingInput) -> Result<Vec<f32>, EmbeddingError> {
        let vector = self.provider.embed_query_with_id(input)?;
        self.vectors.push(vector.clone());
        Ok(vector)
    }
    fn embed_documents(&mut self, _: &[&str]) -> Result<Vec<Vec<f32>>, EmbeddingError> {
        Err(EmbeddingError::Invalid(
            "evaluation must not encode documents".into(),
        ))
    }
    fn embed_query(&mut self, text: &str) -> Result<Vec<f32>, EmbeddingError> {
        let vector = self.provider.embed_query(text)?;
        self.vectors.push(vector.clone());
        Ok(vector)
    }
}

pub fn evaluate(
    code: CodeIndex,
    device: &Device,
    provider: &mut dyn EmbeddingProvider,
    dataset: &QuerySet,
    options: EvaluationOptions,
) -> Result<HybridEvaluationReport, CodeError> {
    evaluate_internal(code, device, provider, dataset, options, false)
}

/// Evaluate and include source-free records for each final retained candidate window.
pub fn evaluate_with_candidates(
    code: CodeIndex,
    device: &Device,
    provider: &mut dyn EmbeddingProvider,
    dataset: &QuerySet,
    options: EvaluationOptions,
) -> Result<HybridEvaluationReport, CodeError> {
    evaluate_internal(code, device, provider, dataset, options, true)
}

fn evaluate_internal(
    code: CodeIndex,
    device: &Device,
    provider: &mut dyn EmbeddingProvider,
    dataset: &QuerySet,
    options: EvaluationOptions,
    export_candidates: bool,
) -> Result<HybridEvaluationReport, CodeError> {
    let config = code
        .embedding_config()
        .cloned()
        .ok_or_else(|| invalid("evaluation requires a provider-aware index"))?;
    let mut capture = CaptureQueries {
        provider,
        vectors: Vec::new(),
    };
    // The original evaluator still owns validation, inference, baseline metrics and precision
    // guards. It runs first and frees its resident indexes before the current variants run.
    let baseline = if export_candidates {
        evaluation::evaluate_with_candidates(code.clone(), device, &mut capture, dataset, options)?
    } else {
        evaluation::evaluate(code.clone(), device, &mut capture, dataset, options)?
    };
    let queries = capture
        .vectors
        .into_iter()
        .map(|v| EmbeddedQuery::new(config.clone(), v))
        .collect::<Result<Vec<_>, _>>()?;
    if queries.len() != dataset.queries.len() {
        return Err(invalid("baseline query capture count mismatch"));
    }
    let relevant = dataset.resolve(&code)?;
    let mut variants = Vec::new();
    for old in baseline.variants {
        let precision = old.snapshot.precision;
        let start = Instant::now();
        let variant = code.clone().with_precision(precision)?;
        let conversion_ms = elapsed_ms(start);
        let start = Instant::now();
        let resident = CodeSearchIndex::new(device, variant)?;
        let upload_ms = elapsed_ms(start);
        let start = Instant::now();
        let text_index = SnapshotTextIndex::new(resident.code());
        text_index.warm_up(SearchStrategy::Hybrid);
        let text_index_ms = elapsed_ms(start);
        let mut results = Vec::new();
        for (((case, query), relevant), old_query) in dataset
            .queries
            .iter()
            .zip(&queries)
            .zip(&relevant)
            .zip(old.queries)
        {
            let start = Instant::now();
            let prepared = text_index.prepare(&case.filter, Some(&resident))?;
            let hybrid_filter_ms = elapsed_ms(start);
            let mut strategies = Vec::new();
            for strategy in [
                SearchStrategy::Lexical,
                SearchStrategy::Symbol,
                SearchStrategy::Hybrid,
            ] {
                let opts = RetrievalOptions {
                    strategy,
                    top_k: options.candidate_k,
                    candidate_k: options.candidate_k,
                    deduplicate: true,
                };
                // Warm each current strategy explicitly; report the original baseline's first
                // semantic invocation separately. This is not a fresh-process cold start.
                prepared.query(&case.text, Some(query), opts)?;
                let mut hits = Vec::new();
                let mut samples = Vec::new();
                for _ in 0..options.repeats {
                    let start = Instant::now();
                    hits = prepared.query(&case.text, Some(query), opts)?.hits;
                    samples.push(elapsed_ms(start));
                }
                strategies.push(strategy_result(
                    resident.code(),
                    &hits,
                    relevant,
                    samples,
                    export_candidates,
                )?);
            }
            let mut strategies = strategies.into_iter();
            results.push(HybridQueryResult {
                baseline: old_query,
                hybrid_filter_ms,
                lexical: strategies.next().unwrap(),
                symbol: strategies.next().unwrap(),
                hybrid: strategies.next().unwrap(),
            });
        }
        let mut overall = old.overall;
        overall.extend(summarize(&results.iter().collect::<Vec<_>>()));
        let mut groups = BTreeMap::<QueryCategory, Vec<&HybridQueryResult>>::new();
        for result in &results {
            groups
                .entry(result.baseline.category)
                .or_default()
                .push(result);
        }
        let mut by_category = old.by_category;
        for (category, rows) in groups {
            by_category
                .entry(category)
                .or_default()
                .extend(summarize(&rows));
        }
        variants.push(HybridVariantReport {
            snapshot: old.snapshot,
            baseline_conversion_ms: old.conversion_ms,
            baseline_upload_ms: old.upload_ms,
            conversion_ms,
            upload_ms,
            text_index_ms,
            queries: results,
            overall,
            by_category,
        });
    }
    Ok(HybridEvaluationReport {
        format_version: if export_candidates { 3 } else { 2 },
        dataset: baseline.dataset,
        backend: baseline.backend,
        options,
        rrf_rank_constant: baseline.rrf_rank_constant,
        embedding_total_ms: baseline.embedding_total_ms,
        embedding_execution: baseline.embedding_execution,
        variants,
    })
}

fn strategy_result(
    code: &CodeIndex,
    hits: &[RetrievalHit],
    relevant: &BTreeSet<usize>,
    mut samples: Vec<f64>,
    export_candidates: bool,
) -> Result<RetrievalStrategyResult, CodeError> {
    let metrics = ranking_metrics(&hits.iter().map(|h| h.row).collect::<Vec<_>>(), relevant)?;
    samples.sort_by(f64::total_cmp);
    let n = samples.len(); // Baseline validation already rejected repeats == 0.
    let median_ms = if n.is_multiple_of(2) {
        (samples[n / 2 - 1] + samples[n / 2]) / 2.0
    } else {
        samples[n / 2]
    };
    let retrieval = Latency {
        median_ms,
        min_ms: samples[0],
        max_ms: samples[n - 1],
        samples: n,
    };
    let candidate_ranking = if export_candidates {
        Some(
            hits.iter()
                .enumerate()
                .map(|(index, hit)| {
                    let chunk = code
                        .chunks()
                        .get(hit.row)
                        .ok_or_else(|| invalid("candidate row is outside the saved snapshot"))?;
                    Ok(RankedCandidate {
                        rank: index + 1,
                        row: hit.row,
                        path: chunk.path.clone(),
                        symbol: chunk.symbol.clone(),
                        score: hit.score,
                    })
                })
                .collect::<Result<Vec<_>, CodeError>>()?,
        )
    } else {
        None
    };
    let start = Instant::now();
    let top_hits = materialize_hits(code, &hits[..hits.len().min(10)], false)?;
    Ok(RetrievalStrategyResult {
        metrics,
        retrieval,
        materialization_ms: elapsed_ms(start),
        top_hits,
        candidate_ranking,
    })
}

fn summarize(results: &[&HybridQueryResult]) -> BTreeMap<String, QualitySummary> {
    ["lexical", "symbol", "hybrid"]
        .into_iter()
        .map(|name| {
            let metrics = results
                .iter()
                .map(|r| match name {
                    "lexical" => r.lexical.metrics,
                    "symbol" => r.symbol.metrics,
                    _ => r.hybrid.metrics,
                })
                .collect::<Vec<_>>();
            let n = metrics.len() as f64;
            (
                name.into(),
                QualitySummary {
                    queries: metrics.len(),
                    recall_at_5: metrics.iter().map(|m| m.recall_at_5).sum::<f64>() / n,
                    recall_at_10: metrics.iter().map(|m| m.recall_at_10).sum::<f64>() / n,
                    mrr: metrics.iter().map(|m| m.reciprocal_rank).sum::<f64>() / n,
                },
            )
        })
        .collect()
}
