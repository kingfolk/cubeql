"""Package the completed trace run and saved-data attribution, without inference."""
from pathlib import Path
import hashlib,io,json,subprocess,tarfile
REPO=Path('/Users/devilhill/Codes/cubeql')
WORK=Path('/Users/devilhill/Documents/ChatGPT/cubeql')
STAGE=WORK/'rq2-trace-stack'
RUN=STAGE/'original64-trace-attempt1'
DIAG=STAGE/'original64-trace-diagnostics'
PREV=WORK/'rq2-candidate-stack/original64-candidates-attempt1'
ORIGINAL=WORK/'rq2-live-stack/full64-2026-11-12-attempt1'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(d):return (json.dumps(d,indent=2,ensure_ascii=False,allow_nan=False)+'\n').encode()
def main():
    execution=json.loads((RUN/'execution.json').read_bytes());assert execution['status']=='ok'
    inp=json.loads((RUN/'inputs.json').read_bytes())
    full=json.loads((DIAG/'diagnostics.json').read_bytes())
    native=json.loads((RUN/'evaluate.stdout').read_bytes())['evaluation']
    comparison=json.loads((RUN/'comparison.json').read_bytes())
    recipe=json.loads((ORIGINAL/'recipe.json').read_bytes())
    members={}
    for prefix,folder in [('run',RUN),('diagnostics',DIAG)]:
        for path in sorted(folder.iterdir()):
            if path.is_file():members[prefix+'/'+path.name]=path.read_bytes()
    for name in ('evaluate.stdout','manifest.json'):
        members['previous/'+name]=(PREV/name).read_bytes()
    members['original/recipe.json']=(ORIGINAL/'recipe.json').read_bytes()
    members['original/manifest.json']=(ORIGINAL/'manifest.json').read_bytes()
    members['inputs/queries.json']=(WORK/'rq2-live-stack/prepared64/recipe/queries.json').read_bytes()
    for name in ('repository_hybrid_trace.py','repository_native_diagnostics.py','repository_baseline.py','repository_collect.py','repository_eval.py','serve_encoder.py'):
        members['producer/tools/'+name]=(REPO/'tools'/name).read_bytes()
    for name in inp['engine_sources_sha256']:
        members['producer/'+name]=(REPO/name).read_bytes()
    for name in ('replay.py','package.py'):
        members['producer/'+name]=(STAGE/name).read_bytes()
    profile_path=Path(recipe['config']['profiles'][0]['encoder_config'])
    profile=json.loads(profile_path.read_bytes())
    members['inputs/encoder-config.json']=profile_path.read_bytes()
    members['runtime/requirements-observed-after-run.txt']=subprocess.check_output([profile['command'],'-m','pip','freeze','--all'])
    variants=[]
    for variant in full['variants']:
        gaps=[q for q in variant['queries'] if any(a['stage'] in ('not_in_filtered_branch_windows','suppressed_by_overlap','truncated_after_deduplication') for a in q['anchors'])]
        regression=next(q for q in variant['queries'] if q['id']=='v2-behavior-biased-first-timing')
        variants.append({k:v for k,v in variant.items() if k!='queries'}|{'missing_final_window_queries':gaps,'retained_regression':regression})
    summary=dict(full,variants=variants,full_diagnostics_archive_member='diagnostics/diagnostics.json')
    metadata={'format_version':1,'engine_revision':inp['engine_revision'],
        'binary_build_revision_independently_attested':False,
        'binary_sha256':inp['observed_inputs_before']['binary_sha256'],
        'engine_sources_sha256':inp['engine_sources_sha256'],
        'original_recipe_fingerprint':inp['original_recipe_fingerprint'],
        'preserved_snapshot_sha256':inp['original_snapshot_sha256'],
        'queries_sha256':recipe['inputs']['queries_sha256'],
        'snapshot':native['variants'][0]['snapshot'],'native_options':native['options'],
        'evaluation_wall_ms':execution['elapsed_ms'],'document_encoding_reused':True,
        'query_encoding':'Live local fixed CodeRank256 CPU; no query-vector replay claim.',
        'corpus_and_build_dependency_revision':'5037c0639ce3b1205392bdbe43dcf25e2ea09e29',
        'benchmark_paid_api_or_agent_calls':0,'large_snapshot_models_and_caches_excluded':True,
        'producer_sha256':{name:sha(data) for name,data in members.items() if name.startswith('producer/')},
        'runtime_lock_boundary':'Observed after execution; not a hermetic environment attestation.'}
    destination=REPO/f'benchmarks/retrieval/cubecl64-hybrid-trace-2026-11-19-{inp["engine_revision"][:7]}'
    destination.mkdir(exist_ok=False)
    buffer=io.BytesIO()
    with tarfile.open(fileobj=buffer,mode='w:gz') as archive:
        for name,data in sorted(members.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
            archive.addfile(info,io.BytesIO(data))
    (destination/'evidence.tar.gz').write_bytes(buffer.getvalue())
    (destination/'evidence-members.json').write_bytes(enc({name:sha(data) for name,data in sorted(members.items())}))
    (destination/'experiment.json').write_bytes(enc(metadata))
    (destination/'trace-summary.json').write_bytes(enc(summary))
    (destination/'comparison.json').write_bytes(enc(comparison))
    print(json.dumps({'destination':str(destination),'members':len(members),'archive_bytes':len(buffer.getvalue()),'uncompressed_bytes':sum(map(len,members.values()))}))
if __name__=='__main__':main()
