# Observed Hybrid stage diagnostics

| Precision | Stage | Anchor judgments | Queries containing stage |
| --- | --- | ---: | ---: |
| fp32 | not_in_filtered_branch_windows | 11 | 7 |
| fp32 | suppressed_by_overlap | 0 | 0 |
| fp32 | truncated_after_deduplication | 5 | 4 |
| fp32 | retained_below_top10 | 15 | 15 |
| fp32 | retained_top10 | 58 | 50 |

Branch windows are filtered and bounded; absence here is not an unbounded retrieval or repository-coverage conclusion.

Suppression uses observed same-file inclusive-range IoU decisions. Query counts can overlap across stages.

- Stage attribution is conditional on the exported filtered, bounded branch windows and fixed pipeline.
- An anchor absent from those branch windows is not proven absent from the repository or the unbounded branch ranking.
- Suppression records are geometric policy decisions, not judgments that the suppressed code is irrelevant.
- Counts of anchor judgments include repeated labels across queries. Queries-with-stage counts can overlap.
- Trace instrumentation can affect the native deduplication and last hybrid warm-repeat timings. No latency improvement or ranking-policy benefit is claimed.
- These positive-label development observations do not establish independently reviewed validation or coding-agent success.
