# Repository retrieval diagnostics

Descriptive location-coverage results on the declared frozen queries. These are not coding-task success rates or controlled equal-work engine comparisons.

| Condition | Queries | Successful coverage | Anchor Recall@10 | All required locations@10 | Exported-window recall | Request median ms |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| cubeql-coderank-lexical | 8 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 0.788 |
| cubeql-coderank-symbol | 8 | 1.0000 | 0.2500 | 0.2500 | 0.2500 | 0.283 |
| cubeql-coderank-semantic | 8 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 50.871 |
| cubeql-coderank-hybrid | 8 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 50.191 |
| semble-potion-native | 8 | 1.0000 | 1.0000 | 1.0000 | 1.0000 | 0.884 |

Each request timing boundary is recorded below; startup, indexing, source reads and native candidate budgets may differ. No speedup ratio or causal ranking attribution is made.

- cubeql-coderank-lexical: resident request wall ms; excludes indexing/startup and source reads; 8 latency observations; exported window 10.
- cubeql-coderank-symbol: resident request wall ms; excludes indexing/startup and source reads; 8 latency observations; exported window 10.
- cubeql-coderank-semantic: resident request wall ms; excludes indexing/startup and source reads; 8 latency observations; exported window 10.
- cubeql-coderank-hybrid: resident request wall ms; excludes indexing/startup and source reads; 8 latency observations; exported window 10.
- semble-potion-native: resident request wall ms; excludes indexing/startup and source reads; 8 latency observations; exported window 10.

## cubeql-coderank-symbol versus cubeql-coderank-lexical

Recall outcomes: {&quot;lost&quot;: 6, &quot;tied&quot;: 2}.

| Query | Repository | Outcome | Baseline recall@10 | Candidate recall@10 | Candidate diagnosis |
| --- | --- | --- | ---: | ---: | --- |
| identifier-config | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| identifier-cosine | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| concept-config | retrieval-fixture | lost | 1.0000 | 0.0000 | missing_from_exported_window |
| concept-product | retrieval-fixture | lost | 1.0000 | 0.0000 | missing_from_exported_window |
| behavior-zero | retrieval-fixture | lost | 1.0000 | 0.0000 | missing_from_exported_window |
| behavior-order | retrieval-fixture | lost | 1.0000 | 0.0000 | missing_from_exported_window |
| cross-prepare | retrieval-fixture | lost | 1.0000 | 0.0000 | missing_from_exported_window |
| cross-rank | retrieval-fixture | lost | 1.0000 | 0.0000 | missing_from_exported_window |

## cubeql-coderank-semantic versus cubeql-coderank-lexical

Recall outcomes: {&quot;tied&quot;: 8}.

| Query | Repository | Outcome | Baseline recall@10 | Candidate recall@10 | Candidate diagnosis |
| --- | --- | --- | ---: | ---: | --- |
| identifier-config | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| identifier-cosine | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| concept-config | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| concept-product | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| behavior-zero | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| behavior-order | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| cross-prepare | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| cross-rank | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |

## cubeql-coderank-hybrid versus cubeql-coderank-lexical

Recall outcomes: {&quot;tied&quot;: 8}.

| Query | Repository | Outcome | Baseline recall@10 | Candidate recall@10 | Candidate diagnosis |
| --- | --- | --- | ---: | ---: | --- |
| identifier-config | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| identifier-cosine | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| concept-config | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| concept-product | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| behavior-zero | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| behavior-order | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| cross-prepare | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| cross-rank | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |

## semble-potion-native versus cubeql-coderank-lexical

Recall outcomes: {&quot;tied&quot;: 8}.

| Query | Repository | Outcome | Baseline recall@10 | Candidate recall@10 | Candidate diagnosis |
| --- | --- | --- | ---: | ---: | --- |
| identifier-config | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| identifier-cosine | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| concept-config | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| concept-product | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| behavior-zero | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| behavior-order | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| cross-prepare | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |
| cross-rank | retrieval-fixture | tied | 1.0000 | 1.0000 | all_locations_in_top10 |

## Interpretation limits

- Recall and all-required metrics measure labeled source locations, not proof that every source byte was returned or used.
- An anchor missing from an exported top-k window may exist in an internal candidate pool; this is not a candidate-generation diagnosis.
- Unjudged results are not automatically false positives. Development queries and incomplete judgments do not establish held-out generalization.
- Different native chunking, models, reranking and candidate budgets remain product-condition differences, not isolated ranking or engine effects.
- Native response payloads and source-read work can differ even when the resident request timing boundary has the same name; no equal-context latency is attested.
- Latency summaries exclude failed queries and missing timing observations; coverage is explicit. Matched timing boundaries do not establish equal internal work.
- These descriptive paired counts are not significance tests, model forecasts, or coding-agent task outcomes.
