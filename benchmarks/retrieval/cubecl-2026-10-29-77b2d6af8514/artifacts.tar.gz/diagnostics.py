#!/usr/bin/env python3
"""Prespecified wording/dedup diagnostics; all embeddings local; no agent calls."""
import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import time
from benchmark import ROOT,CLI,MODEL,sha,save,load,execute

PAIRS={
 'wording-loaded-fast-path':'concept-loaded-kernel-fast-path',
 'wording-compiler-failure':'behavior-compile-error-source',
 'wording-inplace-write':'concept-inplace-write-attribution',
 'wording-scratch-consolidation':'concept-shared-single-block',
 'wording-environment-switch':'behavior-environment-cache-reset',
 'wording-at-least-one-trial':'v2-behavior-zero-patience'}
CASES=['identifier-driver-ptx','v2-identifier-swizzle','concept-packed-conversion',
       'v2-concept-layout-selection','behavior-environment-cache-reset','v2-behavior-biased-first-timing',
       'cross-ssa-merge-frontiers','v2-cross-host-device-scale']


def freeze():
    if (ROOT/'minilm-fp32.arrow').exists():
        raise ValueError('freeze diagnostics before the first semantic rankings are available')
    save(ROOT/'diagnostics-freeze.json',{'frozen_utc':datetime.now(timezone.utc).isoformat(),
        'semantic_rankings_observed':False,'wording_pairs':PAIRS,'dedup_cases':CASES,
        'files':{n:sha(ROOT/n) for n in ('paired-wording-diagnostic.json','diagnostics.py')},
        'note':'diagnostic subset, not independent new quality samples; no posthoc case selection'})


def metrics(hits, relevant):
    keys=[(h['path'],h['symbol']) for h in hits]
    rr=next((1/(i+1) for i,k in enumerate(keys) if k in relevant),0)
    return {'recall_at_5':sum(k in relevant for k in keys[:5])/len(relevant),
            'recall_at_10':sum(k in relevant for k in keys[:10])/len(relevant),
            'reciprocal_rank':rr,'all_anchors_top10':relevant<=set(keys[:10])}


def run():
    frozen=load(ROOT/'diagnostics-freeze.json')
    if any(sha(ROOT/n)!=d for n,d in frozen['files'].items()): raise ValueError('diagnostics changed')
    execute('wording-k50','paired-wording-diagnostic.json',50)
    combined=load(ROOT/'combined-v2-k50.json')['evaluation']
    rows={q['id']:q for q in combined['variants'][0]['queries']}
    wording=load(ROOT/'wording-k50.json')['evaluation']['variants'][0]['queries']
    paired=[]
    for q in wording:
        original=rows[PAIRS[q['id']]]
        paired.append({'id':q['id'],'original_id':original['id'],
                       'metrics':{mode:{'original':original[mode]['metrics'],'reworded':q[mode]['metrics']}
                                  for mode in ('lexical','semantic','hybrid')}})
    save(ROOT/'wording-analysis.json',{'pairs':paired,'warning':'six paired diagnostics, not independent samples'})
    cases={q['id']:q for q in combined['dataset']['queries']}
    out=ROOT/'dedup-diagnostic'
    out.mkdir()
    results=[]
    for number,id in enumerate(CASES):
        q=cases[id]
        relevant={(l['path'],l['symbol']) for l in q['relevant']}
        for mode in ('lexical','semantic','hybrid'):
            for dedup in (True,False):
                name=f'{number:02d}-{mode}-dedup-{dedup}'
                argv=[str(CLI),'search',str(ROOT/'minilm-fp32.arrow'),q['text'],
                      '--strategy',mode,'--language','rust','--candidate-k','50','--top-k','50','--format','json']
                if mode!='lexical': argv+=['--model-dir',str(MODEL)]
                if not dedup: argv+=['--no-dedup']
                start=time.monotonic()
                with (out/(name+'.json')).open('x') as stdout,(out/(name+'.stderr.log')).open('x') as stderr:
                    r=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=120)
                if r.returncode: raise RuntimeError('diagnostic failed: '+name)
                data=load(out/(name+'.json'))
                hits=data['hits']
                legacy=rows[id][mode]['metrics']
                results.append({'id':id,'mode':mode,'deduplicate':dedup,
                    'metrics':metrics(hits,relevant),'original_evaluator_metrics':legacy,
                    'top10':[(h['path'],h['symbol']) for h in hits[:10]],
                    'wall_seconds':time.monotonic()-start,'argv':argv})
    save(ROOT/'dedup-analysis.json',{'runs':results,'model_requests_started':0,
        'scope':'8 prespecified queries, 3 modes, dedup on/off; not a full-suite performance comparison'})


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['freeze','run']);a=p.parse_args()
    freeze() if a.action=='freeze' else run()
