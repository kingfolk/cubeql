# Preserved benchmark protocol and bias audit

Frozen before observing any natural-language query rankings, while the MiniLM indexing
process was still running. This is a public developer-authored diagnostic, not a hidden
test set or an independently human-judged benchmark.

## Unchanged baseline

The original 40 questions are retained byte-for-byte in `queries-v1.json`. Their annotation
and fresh source snapshot have passed the existing validator. Source commit, corpus and
candidate pool will not change between retrieval modes or query-set versions.

## Coverage gap identified without looking at scores

The 40-question bank has only 42 distinct anchors in 20 files, with repeated questions
about the same vector-unrolling, CUDA compilation and device-loss implementations.
Conceptual and behavioral questions can also closely resemble source comments. This can
make aggregate results overconfident and narrow, even if the actual ranking code is correct.

The predeclared 24-question extension broadens coverage to previously unlabeled runtime
autotuning, timing-noise rules, tensor layouts, swizzling, quantization and roofline limits.
It has six queries per existing category. Report it separately from the original bank as
well as in a 64-question combined set; a changed aggregate must not replace the original.
Although frozen before rankings, this extension is still authored by the same assistant
against the same public source; it is not independent validation and may share stylistic bias.

## Planned comparisons

1. Main original-bank run: six existing evaluator strategies, FP32, candidate_k=50,
   warm repeats=3, pinned MiniLM with 256-token truncation and 384 dimensions.
2. Separate extension and combined runs with identical settings.
3. Candidate-budget sensitivity on the combined set, candidate_k=100. Compare Recall@5/10
   consistently; call MRR by its actual cutoff rather than pretending MRR@50 and MRR@100
   are the same statistic.
4. Inspect whether the current evaluator compares undeduplicated legacy semantic/literal/RRF
   against deduplicated lexical/symbol/hybrid. If so, explicitly disclose that confound and
   run a matched deduplication diagnostic with the CLI instead of attributing everything to
   fusion. Do not change retrieval algorithms.
5. Analyze per-query wins/losses, category-level anchor recall, full multi-anchor evidence
   in the top 10, and uncertainty with topic/anchor dependence acknowledged. Warm repeats
   are timing samples, not independent quality trials.

## Stopping rule

Stop when category and per-case evidence can explain the observed strengths/weaknesses,
including a failure to separate some modes. Do not seek a predetermined hybrid win or
keep selecting questions until a significant difference appears. Any further score-informed
query additions must be recorded as exploratory, with old data/results preserved.

No extra Codex/API model executions, commits, pushes, global config writes or PR changes.
Indexing and query embeddings are local CPU MiniLM; this is not an agent-adoption experiment
or a CPU-versus-Metal benchmark. All source annotations remain pending independent review.
