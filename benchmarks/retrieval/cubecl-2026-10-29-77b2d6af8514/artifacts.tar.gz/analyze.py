#!/usr/bin/env python3
"""Offline report analysis; never invoke a model or alter original results."""
from collections import defaultdict
import csv
import json
from pathlib import Path
import random
import statistics

ROOT = Path(__file__).resolve().parent
MODES = ('literal','symbol','lexical','semantic','experimental_rrf','hybrid')


def load(name):
    return json.loads((ROOT/name).read_text())


def save(name, value):
    with (ROOT/name).open('x') as f:
        json.dump(value,f,ensure_ascii=False,indent=2)
        f.write('\n')


def components(queries):
    """Treat questions sharing any evidence anchor as dependent (including transitive links)."""
    parents=list(range(len(queries)))
    def root(i):
        while parents[i]!=i:
            parents[i]=parents[parents[i]]
            i=parents[i]
        return i
    owners={}
    for i,q in enumerate(queries):
        for label in q['relevant']:
            key=(label['path'],label['symbol'])
            if key in owners: parents[root(i)]=root(owners[key])
            owners[key]=i
    groups=defaultdict(list)
    for i in range(len(queries)): groups[root(i)].append(i)
    return list(groups.values())


def bootstrap(rows, groups, a, b):
    rng=random.Random(20261029)
    samples=[]
    for _ in range(2000):
        ids=[i for _ in groups for i in groups[rng.randrange(len(groups))]]
        samples.append(statistics.mean(rows[i][a]['metrics']['recall_at_10']-
                                       rows[i][b]['metrics']['recall_at_10'] for i in ids))
    samples.sort()
    return {'metric':'anchor_recall_at_10','difference':a+' minus '+b,
            'mean_difference':statistics.mean(r[a]['metrics']['recall_at_10']-
                                             r[b]['metrics']['recall_at_10'] for r in rows),
            'descriptive_cluster_bootstrap_95pct':[samples[49],samples[1949]],
            'replicates':2000,'anchor_connected_clusters':len(groups),
            'caution':'not a random sample of real traffic; not a population significance claim'}


def summarize(name):
    raw=load(name+'.json')
    e=raw['evaluation']
    v=e['variants'][0]
    cases={q['id']:q for q in e['dataset']['queries']}
    details=[]
    for q in v['queries']:
        expected={(a['path'],a['symbol']) for a in cases[q['id']]['relevant']}
        detail={'id':q['id'],'category':q['category']}
        for mode in MODES:
            r=q[mode]
            hits={(h['path'],h['symbol']) for h in r['top_hits']}
            detail[mode]={'metrics':r['metrics'],'all_anchors_in_top10':expected<=hits,
                          'retrieval_ms':r['retrieval']['median_ms']}
        details.append(detail)
    groups=components(e['dataset']['queries'])
    for mode in MODES:
        v['overall'][mode]['all_anchors_top10_rate']=statistics.mean(r[mode]['all_anchors_in_top10'] for r in details)
        v['overall'][mode]['median_query_warm_retrieval_ms']=statistics.median(r[mode]['retrieval_ms'] for r in details)
    return {'name':name,'backend':e['backend'],'options':e['options'],
            'overall':v['overall'],'by_category':v['by_category'],
            'model':v['snapshot']['embedding'],'corpus_fingerprint':v['snapshot']['corpus_fingerprint'],
            'timing':{'read_ms':raw['read_ms'],'model_load_ms':raw['model_load_ms'],
                      'embedding_total_ms':e['embedding_total_ms'], 'text_index_ms':v['text_index_ms'],
                      'upload_ms':v['upload_ms'],'baseline_upload_ms':v['baseline_upload_ms']},
            'queries':details,
            'paired_descriptive_intervals':[bootstrap(details,groups,a,b) for a,b in
                [('hybrid','lexical'),('hybrid','semantic'),('lexical','semantic')]],
            'cluster_sizes':sorted(map(len,groups),reverse=True)}


def main():
    summaries=[summarize(n) for n in ('v1-k50','extension-v2-k50','combined-v2-k50','combined-v2-k100')]
    original,extra,combined,larger=summaries
    base={q['id']:q for s in (original,extra) for q in s['queries']}
    mismatches=[]
    for q in combined['queries']:
        for mode in MODES:
            if q[mode]['metrics'] != base[q['id']][mode]['metrics']:
                mismatches.append((q['id'],mode))
    changes=[]
    k100={q['id']:q for q in larger['queries']}
    for q in combined['queries']:
        for mode in MODES:
            before=q[mode]['metrics']['recall_at_10']
            after=k100[q['id']][mode]['metrics']['recall_at_10']
            if before != after: changes.append({'id':q['id'],'mode':mode,'k50_recall10':before,'k100_recall10':after})
    save('analysis.json',{'sets':summaries,'separate_vs_combined_metric_mismatches':mismatches,
                          'candidate_budget_recall10_changes':changes,'extra_model_calls':0})
    with (ROOT/'per-query-metrics.csv').open('x',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['set','id','category','mode','recall5','recall10','reciprocal_rank',
                         'all_anchors_in_top10','warm_median_ms'])
        for s in summaries:
            for q in s['queries']:
                for mode in MODES:
                    r=q[mode];m=r['metrics']
                    writer.writerow([s['name'],q['id'],q['category'],mode,m['recall_at_5'],m['recall_at_10'],
                                     m['reciprocal_rank'],r['all_anchors_in_top10'],r['retrieval_ms']])
    print(json.dumps({'summary':[{k:s[k] for k in ('name','overall','by_category','paired_descriptive_intervals')} for s in summaries],
                      'metric_mismatches':mismatches,'candidate_budget_changes':changes},indent=2))


if __name__=='__main__': main()
