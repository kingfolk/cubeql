#!/usr/bin/env python3
"""Local, no-network/no-agent benchmark orchestration; preserve every raw artifact."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CLI = Path('/Users/devilhill/Codes/cubeql/target/release/cubeql-code')
MODEL = Path('/Users/devilhill/Documents/ChatGPT/cube/cubeql-eval-20261028.p8tCar/minilm')
FINGERPRINT = '3ad4afd5220b95c3987c463f6ebe009c1c5adab2ccac8bc256da69bf8d7176cb'


def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as f:
        json.dump(value, f, indent=2, ensure_ascii=False)
        f.write('\n')


def event(**value):
    value['utc'] = datetime.now(timezone.utc).isoformat()
    with (ROOT / 'progress.jsonl').open('a') as f:
        f.write(json.dumps(value) + '\n')
    print(json.dumps(value), flush=True)


def checked(*args):
    result = subprocess.run([str(CLI), *map(str, args)], capture_output=True, text=True,
                            check=True, timeout=90)
    return json.loads(result.stdout)


def prepare():
    old = load(ROOT / 'queries-v1.json')
    extension = load(ROOT / 'queries-extension-v2.json')
    combined = {'version':1, 'name':'cubecl-combined-development-v2',
                'queries':old['queries'] + extension['queries']}
    if len(combined['queries']) != 64 or len({q['id'] for q in combined['queries']}) != 64:
        raise ValueError('expected 64 unique questions')
    if Counter(q['category'] for q in combined['queries']) != dict.fromkeys(
            ('identifier','conceptual','behavioral','cross_file'), 16):
        raise ValueError('category balance changed')
    save(ROOT / 'queries-combined-v2.json', combined)
    cache = {}
    rows = []
    for q in combined['queries']:
        for label in q['relevant']:
            key = (label['path'],label['symbol'])
            if key not in cache:
                found = checked('search', ROOT/'validation.arrow', label['symbol'],
                    '--strategy','symbol','--path-prefix',label['path'], '--language','rust',
                    '--top-k','100','--candidate-k','1000','--format','json')
                hits = [h for h in found['hits'] if h['path']==key[0] and h['symbol']==key[1]]
                if len(hits) != 1:
                    raise ValueError(f'nonunique evidence {key}: {len(hits)}')
                h = hits[0]
                cache[key] = {k:h[k] for k in ('path','symbol','start_line','end_line')}
                cache[key]['file_sha256'] = sha(ROOT/'source'/label['path'])
        if q['category']=='cross_file' and len({l['path'] for l in q['relevant']}) < 2:
            raise ValueError('not a cross-file question')
        rows.append({'id':q['id'],'resolved':[cache[(l['path'],l['symbol'])] for l in q['relevant']]})
    save(ROOT/'validation-combined-v2.json', {'model_requests_started':0, 'queries':rows,
        'query_count':64,'unique_anchors':len(cache),'files':len({p for p,s in cache}),
        'corpus_fingerprint':FINGERPRINT,'human_review':'pending'})
    save(ROOT/'freeze-v2.json', {'frozen_utc':datetime.now(timezone.utc).isoformat(),
        'rankings_observed':False,'source_revision':'5037c0639ce3b1205392bdbe43dcf25e2ea09e29',
        'cli_sha256':sha(CLI), 'files':{n:sha(ROOT/n) for n in
            ('queries-v1.json','queries-extension-v2.json','queries-combined-v2.json','PROTOCOL.md')},
        'model_artifacts':{n:sha(MODEL/n) for n in ('config.json','tokenizer.json','model.safetensors')},
        'candidate_k':[50,100],'repeats':3,'model_requests_started':0})
    event(phase='prepared',queries=64,anchors=len(cache))


def execute(name, queryfile, k):
    argv = [str(CLI),'evaluate',str(ROOT/'minilm-fp32.arrow'),str(ROOT/queryfile),
            '--model-dir',str(MODEL),'--candidate-k',str(k),'--repeats','3','--format','json']
    save(ROOT/(name+'.invocation.json'),{'argv':argv,'started_utc':datetime.now(timezone.utc).isoformat()})
    start = time.monotonic()
    event(phase='evaluating',name=name)
    with (ROOT/(name+'.json')).open('x') as out, (ROOT/(name+'.stderr.log')).open('x') as err:
        result = subprocess.run(argv,stdout=out,stderr=err,timeout=1800)
    save(ROOT/(name+'.execution.json'),{'exit_code':result.returncode,
        'wall_seconds':time.monotonic()-start,'model_requests_started':0})
    if result.returncode:
        raise RuntimeError(f'{name} failed; preserve logs')
    report = load(ROOT/(name+'.json'))['evaluation']
    if report['variants'][0]['snapshot']['corpus_fingerprint'] != FINGERPRINT:
        raise ValueError('wrong corpus')
    event(phase='evaluated',name=name,wall_seconds=time.monotonic()-start)


def run(wait):
    freeze = load(ROOT/'freeze-v2.json')
    if sha(CLI) != freeze['cli_sha256']:
        raise ValueError('CLI changed after freeze')
    for name, digest in freeze['files'].items():
        if sha(ROOT/name) != digest: raise ValueError('frozen file changed: '+name)
    for name, digest in freeze['model_artifacts'].items():
        if sha(MODEL/name) != digest: raise ValueError('model artifact changed')
    start = time.monotonic()
    while not (ROOT/'minilm-fp32.arrow').exists() or not (ROOT/'minilm-index.json').stat().st_size:
        if not wait or time.monotonic()-start > 3*3600:
            raise RuntimeError('semantic index not ready; do not restart existing indexer')
        time.sleep(30)
    info = checked('inspect',ROOT/'minilm-fp32.arrow','--format','json')
    save(ROOT/'minilm-inspect.json',info)
    snapshot = info['snapshot']
    if snapshot['corpus_fingerprint'] != FINGERPRINT or snapshot['embedding']['model'] != 'sentence-transformers/all-MiniLM-L6-v2':
        raise ValueError('incorrect semantic snapshot')
    save(ROOT/'semantic-snapshot-sha256.json',{'sha256':sha(ROOT/'minilm-fp32.arrow')})
    for name, file, k in [('v1-k50','queries-v1.json',50),
                          ('extension-v2-k50','queries-extension-v2.json',50),
                          ('combined-v2-k50','queries-combined-v2.json',50),
                          ('combined-v2-k100','queries-combined-v2.json',100)]:
        execute(name,file,k)
    event(phase='raw_evaluations_complete',model_requests_started=0)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=['prepare','run'])
    parser.add_argument('--wait-for-index',action='store_true')
    args=parser.parse_args()
    prepare() if args.action=='prepare' else run(args.wait_for_index)
