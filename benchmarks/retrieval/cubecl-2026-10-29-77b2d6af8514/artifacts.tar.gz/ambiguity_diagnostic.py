#!/usr/bin/env python3
"""Exploratory sensitivity for the underspecified query 'anchor'; retain main scores."""
from benchmark import ROOT, load, save

queries = load(ROOT/'combined-v2-k50.json')['evaluation']['variants'][0]['queries']
case = next(q for q in queries if q['id'] == 'v2-identifier-anchor')
subset = [q for q in queries if q['id'] != case['id']]
save(ROOT/'ambiguity-diagnostic.json', {
    'scope': 'post-score diagnostic; no label or main result changes',
    'query': 'anchor', 'excluded_only_in_sensitivity': case['id'],
    'reason': 'The query does not specify autotuning; other returned functions also have the name anchor.',
    'symbol_top_hits': case['symbol']['top_hits'][:3],
    'recall10_excluding_this_one_query': {
        m: sum(q[m]['metrics']['recall_at_10'] for q in subset)/len(subset)
        for m in ('lexical', 'semantic', 'hybrid')},
    'remaining_queries': len(subset), 'additional_model_calls': 0,
})
