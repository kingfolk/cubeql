#!/usr/bin/env python3
"""Post-score exploratory source-span diagnostic; no new model/ranking calls.

Keep exact-symbol metrics unchanged. Separately check whether a returned chunk
fully contains an anchor's source span, and whether its file occurs at all.
Neither surrogate judges whether a result answers the question. File coverage
especially is NOT evidence completeness. No OR/no-answer labels are introduced.
"""
from benchmark import ROOT, load, save

labels = {q['id']: q['resolved'] for q in load(ROOT/'validation-combined-v2.json')['queries']}
queries = load(ROOT/'combined-v2-k50.json')['evaluation']['variants'][0]['queries']
modes = ('literal', 'symbol', 'lexical', 'semantic', 'experimental_rrf', 'hybrid')
rows = []
for q in queries:
    anchors = labels[q['id']]
    results = {}
    for mode in modes:
        hits = q[mode]['top_hits'][:10]
        exact = q[mode]['metrics']['recall_at_10']
        covered = sum(any(h['path'] == a['path'] and h['start_line'] <= a['start_line']
                          and h['end_line'] >= a['end_line'] for h in hits) for a in anchors)/len(anchors)
        files = sum(any(h['path'] == a['path'] for h in hits) for a in anchors)/len(anchors)
        results[mode] = {'exact_anchor_recall10': exact,
                         'anchor_span_coverage10': covered,
                         'anchor_file_presence10': files}
    rows.append({'id': q['id'], 'category': q['category'], 'results': results})
aggregate = {m: {k: sum(q['results'][m][k] for q in rows)/len(rows)
                 for k in rows[0]['results'][m]} for m in modes}
output = {'scope': 'post-score exploratory diagnostic, not replacement relevance judgments',
          'queries': rows, 'aggregate': aggregate, 'additional_model_calls': 0}
save(ROOT/'coverage-diagnostic.json', output)
print(aggregate)
