#!/usr/bin/env python3
"""Validate pinned CubeCL evidence labels using CubeQL; no model or ranking benchmark.

The dataset stays outside the corpus. --snapshot must index the committed export named
in metadata.json. Symbol queries resolve annotations, never tune relevance from rankings.
An existing output is never overwritten. Python 3.12+ standard library only.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess


def call(binary, *args):
    result = subprocess.run([str(binary), *map(str, args)], capture_output=True,
                            text=True, timeout=60, check=True)
    return json.loads(result.stdout)


def sha(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cubeql-code", type=Path, required=True)
    parser.add_argument("--snapshot", type=Path, required=True)
    parser.add_argument("--corpus", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    base = Path(__file__).resolve().parent
    metadata = json.loads((base / "metadata.json").read_text())
    dataset = json.loads((base / "queries.json").read_text())
    assert dataset["version"] == 1 and dataset["name"] == metadata["name"]
    assert len(dataset["queries"]) == metadata["query_count"]
    assert Counter(q["category"] for q in dataset["queries"]) == metadata["categories"]
    assert len({q["id"] for q in dataset["queries"]}) == len(dataset["queries"])
    assert not args.output.exists(), "choose a new output file"
    info = call(args.cubeql_code, "inspect", args.snapshot, "--format", "json")["snapshot"]
    for key in ("corpus_fingerprint", "fallback_lines", "max_file_bytes"):
        assert info[key] == metadata[key], f"wrong source/chunker: {key}"
    assert info["chunks"] == metadata["indexed_chunks"]
    assert info["files"] == metadata["indexed_files"]
    assert Path(info["root"]).resolve() == args.corpus.resolve(), "wrong corpus path"
    cache = {}
    rows = []
    for query in dataset["queries"]:
        assert query["text"].strip() and query["filter"] == {"language": "rust"}
        assert query["relevant"]
        labels = []
        for label in query["relevant"]:
            key = (label["path"], label["symbol"])
            assert label["path"].startswith("crates/") and ".." not in Path(label["path"]).parts
            if key not in cache:
                result = call(args.cubeql_code, "search", args.snapshot, label["symbol"],
                    "--strategy", "symbol", "--path-prefix", label["path"],
                    "--language", "rust", "--top-k", "100", "--candidate-k", "1000", "--format", "json")
                hits = [h for h in result["hits"] if h["path"] == label["path"]
                        and h["symbol"] == label["symbol"]]
                assert len(hits) == 1, f"missing/ambiguous label: {key}; matches={len(hits)}"
                hit = hits[0]
                file = args.corpus / label["path"]
                lines = file.read_text().splitlines()
                assert 1 <= hit["start_line"] <= hit["end_line"] <= len(lines)
                cache[key] = {k: hit[k] for k in ("path", "symbol", "start_line", "end_line")}
                cache[key]["file_sha256"] = sha(file)
            labels.append(cache[key])
        assert len({(l["path"], l["symbol"]) for l in labels}) == len(labels)
        if query["category"] == "cross_file":
            assert len({l["path"] for l in labels}) >= 2, query["id"]
        rows.append({"id": query["id"], "category": query["category"], "resolved": labels})
    report = {"version": 1, "revision": metadata["revision"],
              "corpus_fingerprint": info["corpus_fingerprint"],
              "queries_sha256": sha(base / "queries.json"),
              "metadata_sha256": sha(base / "metadata.json"),
              "validator_sha256": sha(Path(__file__)),
              "snapshot_sha256": sha(args.snapshot),
              "query_count": len(rows), "unique_evidence_anchors": len(cache),
              "evidence_files": len({p for p, _ in cache}),
              "model_requests_started": 0, "semantic_quality_measured": False,
              "human_annotation_review": "pending", "queries": rows}
    with args.output.open("x", encoding="utf-8") as output:
        json.dump(report, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(json.dumps({k: v for k, v in report.items() if k != "queries"}, indent=2))


if __name__ == "__main__":
    main()
