# CubeCL real-repository retrieval benchmark — development draft v1

This is a concrete, source-inspected query bank for CubeQL's existing retrieval evaluator.
It is a **public development set**, not an independent hidden test set, a published
leaderboard, or evidence that one retriever beats another. No paid agent runs or learned
semantic-quality benchmark were performed while creating it.

## Source and scope

- Local repository used: `/Users/devilhill/Codes/cubecl` (clean at authoring time).
- Pinned commit: `5037c0639ce3b1205392bdbe43dcf25e2ea09e29`.
- The checkout has both upstream and fork remotes. This exact commit's availability in
  upstream GitHub has **not** been verified; reproduce from the existing local Git object.
- Indexing the committed export with the current CubeQL chunker produced 1,127 files and
  27,289 chunks. The candidate pool is the repository export, not just the 20 labeled files.
- All queries apply the same `language=rust` filter. No query uses an oracle `path_prefix`.
- 40 English queries: 10 identifier, 10 conceptual, 10 behavioral, 10 cross-file.
- 42 unique positive evidence anchors across 20 source files.
- English was chosen to match the current English MiniLM provider. This does not measure
  multilingual retrieval; the same query wording must be used across comparison arms.

`queries.json` uses the existing CubeQL `QuerySet` v1 schema. Category counts and source
identity live separately in `metadata.json`, so the evaluator's unknown-field checks still work.
`validation.json` records actual resolved symbols, line ranges, source-file SHA-256 values,
and corpus/query/validator fingerprints. It is a label-validation report, not a ranking report.

## Example tasks

The complete questions and labels are in `queries.json`; these summaries are for navigation.

| Query ID | What it asks | Evidence anchor |
| --- | --- | --- |
| `identifier-trivial-unroll` | Locate a named interface | `TriviallyUnrollable` |
| `concept-elementwise-pieces` | Rebuild ordinary elementwise operations into smaller pieces | `unroll_default` |
| `concept-packed-conversion` | Preserve logical element count when physical cast lane counts differ | `CastOp` custom unroll |
| `concept-shader-language-selection` | Choose a supported native shader representation or portable fallback | `AutoCompiler` initialization |
| `concept-inplace-write-attribution` | Attribute an alias output's writes to its original buffer | `KernelLauncher::alias_io` |
| `behavior-reinterpret-unsplittable` | Reject a reinterpret whose narrow side cannot supply enough lanes | `ReinterpretCastOp` custom unroll |
| `behavior-compile-error-source` | Return runtime compiler diagnostics together with generated source | CUDA `compile_to_ptx` |
| `behavior-environment-cache-reset` | Drop loaded kernels after an environment-generation change | compilation-cache reset |
| `cross-cuda-artifact-and-load` | Connect generated PTX artifacts to driver module loading | CUDA artifact + module code |
| `cross-loss-waiter-and-sync` | Connect device-loss wakeups to stream synchronization | poison watcher + graphics stream |
| `cross-shared-offsets-and-rewrite` | Connect aligned shared-memory allocation to IR rewriting | liveness analysis + allocation pass |
| `cross-ssa-merge-frontiers` | Connect allocation promotion's merge points to dominance-frontier traversal | promotion analyzer + frontier calculator |

Identifier queries deliberately remain easy controls. Their success is useful, and the set
must not be curated only to favor semantic search. Conceptual and behavioral queries avoid
simply naming the target function. Cross-file questions request several pieces of evidence.

## Annotation limits

These labels were AI-authored, checked against source and mechanically resolved, but **have
not received independent human annotation review**. They identify required positive evidence
anchors, not every potentially useful implementation, caller, comment, or test. Interpret
Recall@5/10 as recall of the listed anchors, not recall of all semantically relevant code.

All listed anchors contribute to a query's denominator. They are **not OR alternatives**.
Some query families share anchors across categories; do not randomly split paraphrases into
train/test and call that independent validation. Use a separately reviewed, topic-disjoint
set before making broader quality claims.

The corpus naturally includes similarly named methods, tests, and backend-specific variants.
They are candidate distractors, **not exhaustively labeled negatives**. Do not derive precision
or nDCG from this file without additional relevance judgments. No no-answer questions are
included because the current evaluator requires a nonempty relevance list.

The chunker does not evaluate Rust conditional compilation. For example, native and wasm
versions of `PoisonWatch::wait_unless_lost` share the same path/symbol, so the existing evaluator
cannot uniquely resolve that label. Such labels were deliberately excluded rather than
silently choosing one definition. Snapshot-local generic/trait spellings may contain spaces;
the JSON stores the exact names returned by the chunker.

## Reproduce the corpus and validate the labels

Build `cubeql-code` first if necessary; the commands below assume its release executable
already exists. Export committed source into a new temporary directory; do not index these
query/annotation files into the corpus and do not reset or edit the working checkout.

```bash
cubecl_bench_root="$(mktemp -d /tmp/cubecl-retrieval-v1.XXXXXX)"
mkdir "$cubecl_bench_root/source"
git -C /Users/devilhill/Codes/cubecl archive \
  5037c0639ce3b1205392bdbe43dcf25e2ea09e29 \
  | tar -xf - -C "$cubecl_bench_root/source"

# Hash vectors are used ONLY to build a cheap annotation-validation snapshot.
/Users/devilhill/Codes/cubeql/target/release/cubeql-code index \
  "$cubecl_bench_root/source" --embedding hash --dimensions 32 \
  --output "$cubecl_bench_root/validation.arrow" --format json

python3 -B /Users/devilhill/Documents/ChatGPT/cube/cubecl-benchmark-v1/validate.py \
  --cubeql-code /Users/devilhill/Codes/cubeql/target/release/cubeql-code \
  --snapshot "$cubecl_bench_root/validation.arrow" \
  --corpus "$cubecl_bench_root/source" \
  --output "$cubecl_bench_root/validation.json"
```

Validation checks the corpus fingerprint, file/chunk counts, category balance, exact unique
path/symbol resolution, Rust filtering, line bounds, duplicate labels and multi-file labels.
It uses symbol lookup only to resolve annotations; it does not run the natural-language
questions, select labels from their rankings, or optimize fusion parameters.

## Run a learned-embedding comparison later

After reviewing the labels, build a **new** snapshot with the pinned MiniLM provider. Keep
the same source export, filters, query texts, candidate window and precision across variants.
The 27,289-chunk corpus is much larger than the previous smoke corpus: CPU MiniLM encoding
can take substantial time and should not be mistaken for GPU scoring time.

```bash
# Existing verified model directory; this command performs no automatic download.
/Users/devilhill/Codes/cubeql/target/release/cubeql-code index \
  "$cubecl_bench_root/source" --embedding minilm \
  --model-dir /absolute/path/to/pinned-minilm \
  --output "$cubecl_bench_root/minilm.arrow" --format json

/Users/devilhill/Codes/cubeql/target/release/cubeql-code evaluate \
  "$cubecl_bench_root/minilm.arrow" \
  /Users/devilhill/Documents/ChatGPT/cube/cubecl-benchmark-v1/queries.json \
  --model-dir /absolute/path/to/pinned-minilm \
  --candidate-k 50 --repeats 3 --format json
```

The current evaluator reports its implemented retrieval strategies, anchor Recall@5/10 and
MRR@50, overall and per category. These are local retrieval evaluations, not language-model
agent executions. Never present the hash-validation snapshot's ranking as semantic quality.
Do not interpret repeated warm scoring as independent agent-quality trials or end-to-end
CPU-versus-Metal serving performance.

For an agent experiment, derive an explicitly selected task subset using the separate
`tasks`/`question` harness schema and a new execution budget. This query bank alone does not
start any Codex requests or require agent tools to be used.

## Files

- `queries.json`: 40 ready-to-load retrieval questions and evidence labels.
- `metadata.json`: pinned source, corpus settings, counts and annotation limitations.
- `validate.py`: repeatable non-model validation with no output overwrite.
- `validation.json`: successful validation against the local committed export.

The bundle is outside both repositories. Creating it did not modify CubeCL, CubeQL, the
existing PR, global Codex configuration, `APPLICATION.md`, or `milestones.md`.
