# Annotation corrections before rankings

The first extension-validation attempt failed on `PatienceTracker`: both its struct and
inherent-impl header have that same snapshot-local symbol. `SampleSet` has the same issue.
No ranking results had been observed. Both identifier queries now name a unique method;
the ambiguous struct labels were not silently resolved to the first row. The prior draft
and generated combined file are preserved with `.invalid-draft.json` suffixes.

The failed validation's nonunique-label error is a dataset issue, not a failed retriever.
The final extension and final 64-question dataset will be frozen only after all labels pass.
