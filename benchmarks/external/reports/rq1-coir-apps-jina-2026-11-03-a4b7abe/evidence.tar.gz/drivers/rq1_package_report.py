"""Package local RQ1 evidence after the full reference completes; no inference or git mutations."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

WORK=Path('/Users/devilhill/Documents/ChatGPT/cubeql')
REPO=Path('/Users/devilhill/Codes/cubeql')
ROOT=WORK/'rq1-checks/validation-2026-11-02-61f991f'
FULL=ROOT/'full-reference'
ENC=ROOT/'apps-jina-1024-mps'
REL=Path('benchmarks/external/reports/rq1-coir-apps-jina-2026-11-03-a4b7abe')
OUT=WORK/'rq1-dev'/REL

def read(p):return json.loads(p.read_text())
def write(p,value):
    with p.open('x') as s:json.dump(value,s,indent=2)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
s=read(FULL/'summary.json')
assert s['status']=='complete'
assert s['source_head'].startswith('a4b7abe')
OUT.mkdir(parents=True)
BASE=WORK/'rq0-checks/validation-2026-11-01-3b9e3e0/full-saved-8192/scores-cubeql'
assert read(BASE/'request.json')['dataset_sha256']==read(FULL/'scores-cubeql/request.json')['dataset_sha256']
old=read(BASE/'per-query.json');new=read(FULL/'scores-cubeql/per-query.json')
assert set(old)==set(new) and len(new)==3765
changes={qid:new[qid]['ndcg_cut_10']-old[qid]['ndcg_cut_10'] for qid in sorted(new)}
paired={'metric':'direct pytrec per-query nDCG@10','queries':len(changes),
 'better':sum(d>1e-12 for d in changes.values()),'worse':sum(d< -1e-12 for d in changes.values()),
 'equal':sum(abs(d)<=1e-12 for d in changes.values()),
 'mean_delta':sum(changes.values())/len(changes),'per_query_delta':changes,
 'baseline':'RQ0 CodeRankEmbed8192, CPU FP32 saved-vector replay',
 'baseline_metrics_sha256':sha(BASE/'per-query.json'),
 'interpretation':'Observed model/configuration contrast, not a controlled causal ablation or untouched validation set'}
write(OUT/'paired-model-contrast.json',paired)

# Explicit allowlist: own source, rankings/metrics, checksums and diagnostics only.
# No corpus/query text, relevance judgments, model artifacts, vectors, indexes or evaluator source.
members={}
def add(p,name):
    if name in members:raise ValueError(name)
    members[name]=p
for p in FULL.rglob('*'):
    if not p.is_file():continue
    relative=p.relative_to(FULL)
    if p.suffix in {'.arrow','.f32','.npz'} or p.name in {'qrels.json','corpus.jsonl','queries.jsonl','inputs.json'}:continue
    if {'source-snapshot','recipe-source'}.intersection(relative.parts) or p.suffix in {'.json','.trec','.stdout','.stderr','.patch'} or p.name.endswith('.py'):
        add(p,'full-reference/'+str(relative))
for p in [*ENC.glob('attempt-*.json'),*ENC.glob('failure-*.json'),*ENC.glob('encoding-*.json'),ENC/'request.json',ENC/'provenance.json',ENC/'manifest.json']:
    add(p,'encoding/'+p.name)
for p in (ROOT/'apps-jina-1024').glob('*.json'):
    if p.name.startswith(('attempt-', 'failure-')) or p.name in {'request.json','provenance.json'}:
        add(p,'earlier-cpu-attempt/'+p.name)
for p in (ENC/'recipe-source').rglob('*'):
    if p.is_file():add(p,'encoding/recipe-source/'+str(p.relative_to(ENC/'recipe-source')))
for name in ['jina-reference-predeclared.json','jina-reference-mps-predeclared.json','tiny-cpu-mps-parity.json','cpu-mps-128-document-parity.json','final-rust-tests.log','followup-checks.json','post-encoding-cleanup-checks.json']:
    add(ROOT/name,'acceptance/'+name)
add(ROOT/'product-acceptance-v2/acceptance.json','acceptance/product.json')
add(ROOT/'product-acceptance/harness-failure.json','acceptance/earlier-harness-failure.json')
for name in ['per-query.json','summary.json','request.json']:
    add(BASE/name,'baseline-coderank8192/'+name)
add(WORK/'rq1_score_full.py','drivers/rq1_score_full.py')
add(Path(__file__),'drivers/rq1_package_report.py')
manifest={'format_version':1,'kind':'rq1-local-reference-evidence','source_head':s['source_head'],
    'source_dirty':True,'binary_sha256':s['binary_sha256'],
    'files_sha256':{n:sha(p) for n,p in sorted(members.items())},
    'excluded':['corpus/query text','qrels','vectors/checkpoints','weights','Arrow indexes','third-party evaluator source']}
with (OUT/'evidence.tar.gz').open('xb') as target,gzip.GzipFile(fileobj=target,mode='wb',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tf:
    for name,p in sorted(members.items()):
        data=p.read_bytes(); info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        tf.addfile(info,io.BytesIO(data))
manifest['archive_sha256']=sha(OUT/'evidence.tar.gz')
write(OUT/'summary.json',s)

c=s['scores']['cubeql']; n=s['scores']['numpy']; p=s['parity_summary']; report=read(FULL/'cubeql/report.json')
full_parity=read(FULL/'numpy/parity.json')
max_gap=max((d['reference_score_gap'] for q in full_parity['mismatches'] for d in q['differences']),default=0.)
e=s['encoding']; t=e['timings']
rows=[]
for label,stats in [('CubeQL CPU, FP32 cosine',c),('NumPy, exhaustive float64 cosine',n)]:
    d=stats['direct_pytrec_unrounded']
    rows.append(f"| {label} | {d['ndcg_cut_10']:.10f} | {d['recall_10']:.10f} | {d['recall_100']:.10f} | {d['recip_rank']:.10f} |")
quality='\n'.join(rows)
lookup=sum(q['embedding_ms'] for q in report['queries'])
retrieval=sum(q['retrieval_ms'] for q in report['queries'])
metrics={'document_input_count':8765,'query_input_count':3765,'source_head':s['source_head'],
    'source_dirty':True,'binary_sha256':s['binary_sha256'],
    'retrieval_backend':report['backend'],'embedding_execution':report['embedding_execution'],
    'timings':{'model_load_successful_attempt_seconds':e['model_load_seconds'],
        'document_inference_seconds_including_reused_batches':t['documents']['inference_seconds_including_reused_batches'],
        'query_inference_seconds_including_reused_batches':t['queries']['inference_seconds_including_reused_batches'],
        'document_rows_reused_on_successful_attempt':t['documents']['rows_reused'],
        'document_vector_lookup_ms':report['document_embedding_ms'],
        'query_vector_lookup_ms':lookup,'index_setup_upload_ms':report['index_setup_upload_ms'],
        'retrieval_ms_sum':retrieval,'retrieval_ms_mean':retrieval/3765},
    'scores':s['scores'],'parity_summary':p,'max_reference_gap_in_reordered_positions':max_gap,'paid_model_calls':0}
write(OUT/'measurements.json',metrics)
text=f'''# RQ1 production vector workflow and Jina reference — 2026-11-03

RQ1 makes externally encoded code vectors usable through CubeQL's supported CLI and library
APIs. This report validates persistence, query-only encoding and incremental reuse, then
runs a stronger local embedding reference through that same production import path.
All work remains local and uncommitted. No paid model calls were made.

## Measured source and frozen condition

- CubeQL base commit: `{s['source_head']}` **plus the uncommitted RQ1 delta**.
  The directory suffix identifies the base, not a clean committed build. The archive contains
  the changed/new source snapshot, tracked patches and exact executable SHA-256.
- CubeCL: `5037c0639ce3b1205392bdbe43dcf25e2ea09e29`; Apple M1, 16 GiB.
- CoIR APPS: all 8,765 candidate documents and all 3,765 official test queries, full judged
  denominator, fixed Top-100. Canonical input order/text match the RQ0 dataset hashes.
  Preparation exports no relevance judgments to the encoder.
- Jina: `jinaai/jina-code-embeddings-0.5b`, revision
  `4db235132dafbe56a8b9c5f59b59795ecf58a4a7`, 896 dimensions, FP32/SDPA, context 1,024,
  last nonpadding token, L2 normalization, official NL2Code query/document prefixes.
- Inference: PyTorch MPS. Retrieval: `{report['backend']}` via CubeCL, FP32 cosine.
  MPS inference is distinct from a CubeCL Metal retrieval run. NumPy uses the identical saved
  FP32 vectors with exhaustive float64 cosine and four BLAS threads.
- The CPU condition and separate MPS condition were declared before relevance scoring.
  CPU encoding was interrupted because of runtime cost. MPS exhausted its allocator memory
  limit on `{len(s['encoding_failures'])}` attempts; fresh processes resumed the identical
  frozen contract and reused validated checkpoints. This is a resource limitation of the
  optional local inference recipe, not an inference-free production service guarantee.
  No allocator safety limit was disabled and no CPU/MPS matrices were mixed.

Input lengths beyond the 1,024-token limit (after each role's prefix) were
`{t['documents']['beyond_context']}` / 8,765 documents and
`{t['queries']['beyond_context']}` / 3,765 queries. Those inputs were truncated, not dropped.
This shorter local condition was frozen before scoring and was not tuned against its results.

Exact artifact/model/input/library identities and attempt history are in `evidence.tar.gz`.
The encoder producer source is retained under `encoding/recipe-source` in the archive.
After its completed stage was sealed, an unused machine-specific staging import fallback
was removed and the eight Python checks passed again; normal repository lookup, inference
math and embedding configuration did not change. Replay does not execute the encoder.
The later source snapshot retains this cleanup separately from the frozen producer.

The original validation workspace name ends in `61f991f` because it was allocated before
RQ0 was merged. Actual encoder/replay provenance records the measured merge base above.

## Quality on the full frozen task

The following are unrounded direct pytrec metrics on the exported Top-100, after the
explicit self-ID policy. nDCG and reciprocal rank are normalized metrics, not accuracy.

| Engine, identical Jina vectors | nDCG@10 | Recall@10 | Recall@100 | Reciprocal rank in Top-100 |
|---|---:|---:|---:|---:|
{quality}

Native CoIR scores and its stable-score MRR tie policy are preserved separately in
[summary.json](summary.json); direct pytrec may order exact score ties differently.
The complete raw rankings and every query's metrics are retained, including misses and ties.

For historical context, the frozen RQ0 experiments measured native nDCG@10 of 0.06596 for
MiniLM-256, 0.19840 for CodeRankEmbed-256 and 0.23460 for CodeRankEmbed-8192. Those are
separate model/configuration experiments, not a controlled ablation of model training or
context length, and were not re-encoded for this report. Matching dataset hashes and all
3,765 query IDs, Jina has higher per-query direct nDCG@10 on `{paired['better']}` queries,
lower on `{paired['worse']}`, and equal on `{paired['equal']}` versus the saved
CodeRankEmbed-8192 control. Exact deltas are in
[paired-model-contrast.json](paired-model-contrast.json). This is an observed model/configuration
contrast; the inspected APPS test set is not an untouched validation set.

Jina's paper reports APPS nDCG@10 × 100 of 84.17; a public peer experiment reports 83.86.
They are author/peer reference values, not locally run competitor products. The paper used
8,192 tokens, FP16 and batch size 8; this run uses 1,024 tokens, FP32 and deterministic
length-based batches. Our context,
precision, preprocessing and evaluation details must accompany comparisons; agreement after
rounding is not proof of reproducing the entire published setup. The measured native
nDCG@10 × 100 is `{c['native_coir']['ndcg']['NDCG@10']*100:.3f}`; its difference from
the paper value is `{c['native_coir']['ndcg']['NDCG@10']*100-84.17:+.3f}` points.
This remains a local implementation of the disclosed recipe, rather than a verified exact
reproduction of the authors' hardware/precision pipeline. The paper explicitly lists
APPS training data, so this task is partly in-domain and does not establish performance on
unseen repositories. CodeRankEmbed's model card describes CoRNStack training; unknown APPS
exposure must not be inferred either way.

## Numerical control and acceptance checks

All parity diagnostics, including any near-tie order differences, remain in the archive.
Top-10 order agrees for `{p['top10_order_identical']}` / 3,765 queries; Top-100 order
for `{p['topk_order_identical']}` / 3,765; Top-100 candidate sets for
`{p['topk_set_identical']}` / 3,765. The largest reference-score gap in reordered
positions is `{max_gap:.12g}`. None of those queries were excluded or perturbed.
Maximum returned cosine-score error: `{p['max_returned_score_error']:.12g}`;
the declared local bound was `5e-6`. Native aggregate nDCG equal: `{s['aggregate_native_ndcg_equal']}`;
native aggregate MRR equal: `{s['aggregate_native_mrr_equal']}`.
A separately recorded fixed 128-document CPU/MPS sample had maximum coordinate error
`2.8796494007e-6` and minimum cosine `0.999999999810103`. This is a numerical sample,
not a backend performance comparison; full inference vectors all come from MPS.

| Acceptance check | Observed result |
|---|---|
| Default `cubeql-code` and `cubeql-embeddings` Rust suite | 63 passed |
| Final identified-vector/evaluator integration suite | 7 passed after timer-label changes |
| Python bundle/recipe/reference checks | 8 passed |
| Existing native/scoring/checkpoint recipe suite | 13 passed |
| Existing real MiniLM provider integration | Passed with verified local model artifacts |
| Real CodeRank CPU, Jina CPU and Jina MPS tiny workflows | Persisted indexes; `load_config` Top-1 |
| New query with query-only encoding | `save_config` Top-1; document corpus not encoded again |
| No-op external-model update | 0 embedded, 3 reused |
| One modified function body | 1 embedded, 2 reused |
| Source/order/text/config mismatch and invalid-vector controls | Rejected; no index output |
| Rust formatting and diff whitespace | Passed |
| Full production CLI replay, NumPy reference, native scores | 3,765 queries retained and verified |

The earlier tiny harness expected a nested JSON hit field whereas the actual CLI flattens
source fields. Its failure is retained separately; correcting that harness did not change
ranking. Initial invocation of the ignored MiniLM test omitted its required model-directory
environment variable; the documented invocation with the local cache passed.

## Timings and resource interpretation

- Model load on the successful resume attempt: `{e['model_load_seconds']:.3f}` s.
- Successful document batches' inference, including checkpoints from earlier attempts:
  `{t['documents']['inference_seconds_including_reused_batches']:.3f}` s;
  queries: `{t['queries']['inference_seconds_including_reused_batches']:.3f}` s.
  These successful batch durations include per-batch tokenization, transfer, forward, pooling
  and readback; they exclude the preliminary length scan and checkpoint I/O. Failed work,
  interruption and model-load time are
  additional. They are not uninterrupted wall-clock throughput measurements.
- Document vectors reused on the successful attempt: `{t['documents']['rows_reused']}`.
- Replay document-vector lookup/validation: `{report['document_embedding_ms']:.3f}` ms;
  all query lookups: `{lookup:.3f}` ms; index setup/upload: `{report['index_setup_upload_ms']:.3f}` ms.
- Total query retrieval timers: `{retrieval:.3f}` ms, mean `{retrieval/3765:.3f}` ms/query.
  This is one sequential local run, includes its cold query, and has no repeated resident
  benchmark or controlled competing load. It is not an end-to-end query-encoding latency.

The CLI labels replay as `precomputed-vector-lookup`; imported lookup timers must not be
reported as model inference. This work establishes neither CPU-versus-Metal speed nor agent
success improvements. See [measurements.json](measurements.json) for machine-readable values.

## Reproduction and retained evidence

Follow [the supported vector workflow](../../../../docs/precomputed-vectors.md) and
[portable benchmark recipe](../../README.md). Use new output directories for new jobs;
resume only incomplete jobs with the exact original request and source identity.

The production sequence is `benchmark prepare` → external `encode` →
`benchmark run --embedding precomputed --vectors ...` → independent `reference` → native
`score` for both engines. Pinned model specs and requirements ship under `tools/`.

[evidence.tar.gz](evidence.tar.gz) retains ID/score rankings, TREC exports, per-query and
aggregate metrics, parity diagnostics, attempt/failure history, frozen requests, source
snapshots, command exit records, test evidence and provenance. [manifest.json](manifest.json)
lists archive members and SHA-256 checksums, plus the archive checksum. Weights, corpus/query
text, relevance judgments, raw vector matrices, Arrow indexes and evaluator source are
excluded. The original full local stage retains those separately for continued development.
A checksum establishes integrity, not an independent build attestation.

This is one CoIR task and a local reference, not the complete CoIR suite, an independently
reproduced competitor product, or a new untouched held-out evaluation. Jina weights are
CC-BY-NC-4.0 and remain an optional noncommercial reference; CodeRankEmbed is MIT according
to its pinned model card. Heavy model inference remains outside the generic core library.
RQ2 is still needed for independently run search-product and exact-engine comparisons.

Sources: [Jina model card](https://huggingface.co/jinaai/jina-code-embeddings-0.5b),
[Jina paper, including training-data disclosure](https://arxiv.org/html/2508.21290v2),
[CodeRankEmbed model card](https://huggingface.co/nomic-ai/CodeRankEmbed),
[pinned peer experiment](https://github.com/utkrshm/agentic-retrieval/blob/095f2b7326ae632ec4a0c6e9286c44a380181ecb/docs/experiments/07-benchmark-apps.md).
'''
with (OUT/'README.md').open('x') as f:f.write(text)
manifest['report_files_sha256']={p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='manifest.json'}
write(OUT/'manifest.json',manifest)
print(OUT)
print('archive bytes', (OUT/'evidence.tar.gz').stat().st_size, 'members',len(members))
