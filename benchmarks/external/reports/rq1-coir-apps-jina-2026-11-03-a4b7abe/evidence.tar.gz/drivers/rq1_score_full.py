"""Post-encoding validation; explicit single invocation, no background polling or models."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import time

REPO=Path('/Users/devilhill/Codes/cubeql')
ROOT=Path('/Users/devilhill/Documents/ChatGPT/cubeql/rq1-checks/validation-2026-11-02-61f991f')
DATA=ROOT.parents[1]/'rq0-checks/inputs/dataset'
CACHE=ROOT.parents[1]/'rq0-checks/evaluator'
PY=ROOT.parent/'.venv-jina/bin/python'
CLI=REPO/'target/release/cubeql-code'
RUNNER=REPO/'benchmarks/external/runner.py'
VECTORS=ROOT/'apps-jina-1024-mps/vectors.json'
OUT=ROOT/'full-reference'

def load(path):return json.loads(path.read_text())
def write(path,value):
    with path.open('x') as stream:json.dump(value,stream,indent=2)

assert (VECTORS.parent/'manifest.json').is_file(), 'encoding must complete first'
OUT.mkdir()
def run(label,args):
    before=time.perf_counter()
    with (OUT/f'{label}.stdout').open('xb') as stdout,(OUT/f'{label}.stderr').open('xb') as stderr:
        result=subprocess.run(list(map(str,args)),cwd=REPO,stdout=stdout,stderr=stderr)
    write(OUT/f'{label}.command.json',{'argv':list(map(str,args)),'exit_code':result.returncode,
        'wall_seconds':time.perf_counter()-before})
    assert result.returncode==0,(label,(OUT/f'{label}.stderr').read_text())
    print('PASS',label,flush=True)

run('verify-encoding',[PY,'-B',RUNNER,'verify',VECTORS.parent])
run('cubeql',[CLI,'benchmark','run',DATA,'--embedding','precomputed','--vectors',VECTORS,
    '--output',OUT/'cubeql','--top-k','100','--run-tag','cubeql-jina-mps-fp32'])
run('numpy',[PY,'-B',RUNNER,'reference',DATA,'--vectors',VECTORS,'--top-k','100',
    '--compare-report',OUT/'cubeql/report.json','--output',OUT/'numpy'])
for engine in ['cubeql','numpy']:
    run('score-'+engine,[PY,'-B',RUNNER,'score',DATA,'--results',OUT/engine/'results.json',
        '--trec',OUT/engine/'run.trec','--candidate-window','100','--cutoffs','1','5','10','100',
        '--evaluator-cache',CACHE,'--output',OUT/('scores-'+engine)])
    run('verify-scores-'+engine,[PY,'-B',RUNNER,'verify',OUT/('scores-'+engine)])

report=load(OUT/'cubeql/report.json')
assert report['embedding_execution']=='precomputed-vector-lookup'
assert len(report['queries'])==3765
scores={engine:load(OUT/f'scores-{engine}/summary.json') for engine in ['cubeql','numpy']}
parity=load(OUT/'numpy/parity.json')
assert parity['max_returned_score_error']<5e-6,parity['max_returned_score_error']
snapshot=OUT/'source-snapshot';snapshot.mkdir()
stage=Path('/Users/devilhill/Documents/ChatGPT/cubeql/rq1-dev')
source_files=[]
for source in stage.rglob('*'):
    relative=source.relative_to(stage)
    if not source.is_file() or {'target','__pycache__','.venv'}.intersection(relative.parts):continue
    if source.name in {'milestones-retrieval-quality.md','Cargo.lock'}:continue
    actual=REPO/relative
    target=snapshot/relative;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(actual,target)
    source_files.append(str(relative))
shutil.copyfile(REPO/'Cargo.lock',snapshot/'Cargo.lock')
write(OUT/'summary.json',{'status':'complete','source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
    'source_dirty':True,'binary_sha256':hashlib.sha256(CLI.read_bytes()).hexdigest(),
    'rustc_verbose_version':subprocess.check_output(['rustc','-Vv'],cwd=REPO,text=True).strip(),
    'cargo_version':subprocess.check_output(['cargo','-V'],cwd=REPO,text=True).strip(),
    'source_snapshot_files':source_files+['Cargo.lock'],'scores':scores,
    'parity_summary':{k:v for k,v in parity.items() if k!='mismatches'},
    'aggregate_native_ndcg_equal':scores['cubeql']['native_coir']['ndcg']==scores['numpy']['native_coir']['ndcg'],
    'aggregate_native_mrr_equal':scores['cubeql']['native_coir']['mrr']==scores['numpy']['native_coir']['mrr'],
    'encoding':load(sorted(VECTORS.parent.glob('encoding-*.json'))[-1]),
    'encoding_completion_file':sorted(VECTORS.parent.glob('encoding-*.json'))[-1].name,
    'encoding_failures':[load(p) for p in sorted(VECTORS.parent.glob('failure-*.json'))],
    'paid_model_calls':0})
print('FULL REFERENCE COMPLETE',flush=True)
