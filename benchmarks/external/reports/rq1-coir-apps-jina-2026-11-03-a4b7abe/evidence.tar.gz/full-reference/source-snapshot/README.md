# cubeql

A minimal Arrow-native retrieval engine powered by CubeCL.

The workspace also includes `cubeql-code`, a repository-to-Arrow index builder with Rust
syntax-aware chunks, line-based fallbacks and incremental embedding reuse:

```bash
cargo run -p cubeql-code -- index ../cubecl --output /tmp/cubecl-code-v1.arrow
cargo run -p cubeql-code -- index ../cubecl --previous /tmp/cubecl-code-v1.arrow \
  --output /tmp/cubecl-code-v2.arrow
```

The CLI defaults to deterministic token-hash vectors for offline pipeline validation, **not
semantic embeddings**. An optional CPU MiniLM provider now supplies real learned embeddings,
with batched documents, model/configuration validation and offline queries:

```bash
cargo run -p cubeql-code --features local-embeddings -- model download --directory /tmp/cubeql-minilm
cargo run -p cubeql-code --features local-embeddings -- index \
  crates/cubeql-code/tests/fixtures/semantic-demo \
  --embedding minilm --model-dir /tmp/cubeql-minilm --output /tmp/demo-minilm.arrow
cargo run -p cubeql-code --features local-embeddings -- query /tmp/demo-minilm.arrow \
  "Where do we read configuration from a file?" --model-dir /tmp/cubeql-minilm
```

MiniLM is a general English sentence model, not a code-specialized retrieval model. The generic
`cubeql` engine has no embedding/model dependencies; `cubeql-embeddings` is a separate optional
application-layer component. See [docs/embedding-providers.md](docs/embedding-providers.md) for
the provider API, reproducibility contract and CLI, and
[docs/code-index-builder.md](docs/code-index-builder.md) for code chunking and incremental rules.

The code-search CLI also supports `update`, host-only `inspect`, filtered `search` (`query` is
an alias), JSON/source output and FP16 snapshots. A labeled evaluator compares vector search,
literal matching and experimental RRF with Recall@5/10, MRR and phase-separated timings on CPU
or Metal, including paired FP32/FP16 runs. See
[docs/code-search-evaluation.md](docs/code-search-evaluation.md) for commands, report semantics
and the limitations of the small synthetic benchmark. Core `cubeql` remains a generic library.

Versioned [retrieval benchmark reports](benchmarks/retrieval/README.md) record experiments
against pinned real repositories, with English reports, query labels, per-query results and
source/model/binary provenance. Each run uses a dated directory ending in its recorded CubeQL
commit, so measurements from different code revisions remain separate.

For external datasets, `cubeql-code benchmark validate/run` imports standard corpus/query
JSONL and qrels TSV, preserves document IDs and units, and exports native JSON/TREC rankings
for an external evaluator. See [docs/external-benchmarks.md](docs/external-benchmarks.md) for
the format, offline smoke example, provenance and scoring boundaries.

The [external embedding workflow](docs/precomputed-vectors.md) adds supported CLI/library
imports of ID/content-bound vector bundles, pinned CodeRankEmbed encoding, query-only
bundles and incremental reuse. Model inference remains separate from the retrieval engine;
an optional Jina reference has its own environment and noncommercial model terms.

The [portable benchmark recipe](benchmarks/external/README.md) adds pinned CoIR APPS
preparation, resumable CodeRankEmbed encoding, an ID-checked vector replay example,
independent cosine checks and native scoring. Its historical ranking bundle can be audited
and rescored without rerunning model inference; corpora and weights stay outside Git.

Snapshot-local hybrid retrieval adds `search --strategy semantic|lexical|symbol|hybrid`,
identifier-aware keyword lookup, exact syntax-symbol search, source-rank provenance and optional
overlap suppression. Lexical/symbol modes do not load a model or initialize a device; hybrid
fuses all three sources. The evaluator retains the old baselines and compares the current
strategies on the same labels. See [docs/hybrid-retrieval.md](docs/hybrid-retrieval.md) for API,
JSON v2, commands and measured limitations; fusion is not assumed to outperform its inputs.

`cubeql-mcp` exposes read-only `search_code` and paginated `read_code` tools over MCP stdio.
A persistent worker reuses one immutable snapshot, host text indexes and, when enabled, the
model/device index. Search returns compact previews and snapshot-bound chunk IDs; reading never
opens arbitrary paths or the live checkout. See [docs/mcp-code-search.md](docs/mcp-code-search.md)
for startup commands, client configuration, limits, traces and integration status.

New snapshots also record whole-file hashes. With an explicit `--workspace-root`, MCP's
`check_code` reports whether a saved hit's current file is unchanged, modified, missing or
unverifiable. Search/read remain snapshot-local; checks neither refresh the index nor lock files.
See [docs/workspace-freshness.md](docs/workspace-freshness.md) for the guard's scope and limits.

An opt-in [coding-agent evaluation runner](docs/harness-evaluation.md) prepares pinned Git source,
then compares Codex CLI with ordinary tools versus added lexical/hybrid MCP retrieval. It records
raw JSONL events, citation/location grading, tool adoption, latency and reported token usage.
Preparation/offline tests make no LLM requests; real execution requires an explicit model,
`--execute` and a run-count limit. No agent-quality improvement is claimed without real trials.

The current prototype intentionally implements one complete path only:

- input: Apache Arrow `RecordBatch`;
- vectors: `FixedSizeList<Float32>` or `FixedSizeList<Float16>`;
- query: exact inner product, cosine similarity, or squared L2 distance;
- metadata predicates: floating-point equality/ranges, string equality/set membership, path prefixes;
- reusable selections with AND semantics, compact scoring or in-kernel masks;
- versioned Arrow IPC persistence preserving metadata and normalization options;
- reusable device-resident indexes for repeated queries;
- execution: CubeCL (CPU by default, with CUDA/HIP/Metal/WGPU feature switches);
- top-k: exact device-side selection; only the final k row IDs and scores are read back.

For repeated queries, construct a `VectorIndex` once so the embedding column remains on the
selected device:

```rust
let device = cubecl::Device::default();
let index = cubeql::VectorIndex::new(&device, batch, "embedding")?;

let hits = index.query(
    &[1.0, 0.0, 0.0],
    cubeql::IndexQueryOptions {
        top_k: 10,
        filter: Some(cubeql::FloatFilter {
            column: "quality",
            min: 0.5,
        }),
    },
)?;
```

The original `query` function remains available as a convenience for one-shot queries. It builds
a temporary `VectorIndex` internally.

Select a metric explicitly when querying a resident index:

```rust
let hits = index.query_with_metric(
    &[1.0, 0.0, 0.0],
    cubeql::IndexQueryOptions::new(10),
    cubeql::Metric::Cosine,
)?;
```

`InnerProduct` and `Cosine` return the largest scores first. `SquaredL2` returns the smallest
distances first (scores are distances, not their negation). Equal scores are ordered by ascending
row ID, with signed zeros treated as equal. Cosine involving a zero vector is defined as zero.
Inputs must be finite; FP32 arithmetic can still overflow, in which case NaN scores are omitted
and infinite scores remain eligible.

Optional index normalization is available through
`VectorIndex::new_with_options(&device, batch, "embedding", IndexOptions { normalize: true })`.
It normalizes the resident vectors, preserving FP16/FP32 storage and the original Arrow batch.
Queries are used as supplied, so normalize them too if unit-length inner products are desired.

The portable top-k implementation uses repeated selection within tiles followed by merge stages.
It is intended for small k: selection costs approximately O(N * k), and requesting every row can
be expensive. Scoring and temporary buffers remain O(N); the host readback is at most 8 * k bytes.

Prepare a selection once for repeated metadata-filtered queries:

```rust
let filters = [
    cubeql::Filter::StringEq { column: "language", value: "rust" },
    cubeql::Filter::PathPrefix { column: "path", prefix: "crates/opt/" },
    cubeql::Filter::FloatRange { column: "quality", min: Some(0.8), max: None },
];
let selected = index.prepare_filter(&filters, cubeql::FilterMode::BeforeScoring)?;
let hits = selected.query(&query_vector, 10, cubeql::Metric::Cosine)?;
```

Metadata is evaluated on the host. Compact mode uploads only matching original row IDs; mask
mode uploads one UInt32 per row and checks it in the scoring kernel. Strings remain in Arrow
host memory. The selection is bound to its index and reused without re-evaluating predicates.
Null metadata never matches, and range endpoints are inclusive. The original `FloatFilter`
API retains its existing FP16/FP32 and null-rejection behavior.

Save and restore an index with:

```rust
index.save_ipc("code-index.arrow")?; // Fails if the file already exists.
let restored = cubeql::VectorIndex::load_ipc(&device, "code-index.arrow")?;
```

The file contains the original Arrow batch and index configuration, not device pointers. Loading
uploads vectors once to the chosen backend. See [docs/metadata-persistence.md](docs/metadata-persistence.md)
for supported types, format details, and the filtering benchmark.

Run the end-to-end FP32 and FP16 tests with:

```bash
cargo test
```

Compare index-loading, warm-query, and one-shot-query costs with:

```bash
cargo bench --bench resident_index
```

Compare direct CPU scoring/partial selection with CubeCL scoring/device selection across dataset
sizes (128 dimensions, top-10):

```bash
cargo bench --bench metrics_top_k
# Native Metal on Apple hardware:
cargo bench --no-default-features --features metal --bench metrics_top_k
```

These benchmarks include scoring, selection, and final readback, and exclude index loading.
See [docs/metrics-top-k.md](docs/metrics-top-k.md) for the selection algorithm, numeric rules,
and initial CPU/Metal measurements.

Compare compact filtering with in-kernel masks at different selectivities:

```bash
cargo bench --bench metadata_filters
cargo bench --no-default-features --features metal --bench metadata_filters
```

The default feature uses CubeCL's CPU runtime so tests work without a GPU. Select another runtime
when building an application, for example `--no-default-features --features cuda` or
`--no-default-features --features wgpu`.
